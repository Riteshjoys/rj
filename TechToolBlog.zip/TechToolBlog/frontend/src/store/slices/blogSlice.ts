import { createSlice, createAsyncThunk, PayloadAction } from '@reduxjs/toolkit';
import { blogApi, categoryApi } from '../../services/api';

interface Blog {
  id: string;
  title: string;
  slug: string;
  content: string;
  content_json?: any;
  excerpt?: string;
  featured_image?: string;
  author_id: string;
  status: 'draft' | 'published';
  view_count: number;
  like_count: number;
  published_at?: string;
  created_at: string;
  updated_at: string;
  categories: Array<any>;
  author: any;
}

interface BlogComment {
  id: string;
  blog_id: string;
  user_id: string;
  content: string;
  created_at: string;
  updated_at: string;
  user: any;
}

interface Category {
  id: string;
  name: string;
  description?: string;
  parent_id?: string;
  is_for_tools: boolean;
  is_for_blogs: boolean;
  created_at: string;
  updated_at: string;
  subcategories?: Category[];
}

interface BlogState {
  blogs: Blog[];
  currentBlog: Blog | null;
  comments: BlogComment[];
  categories: Category[];
  isLoading: boolean;
  error: string | null;
  hasMore: boolean;
  filters: {
    page: number;
    per_page: number;
    sort_by?: string;
    order?: 'asc' | 'desc';
    category_id?: string;
    search?: string;
  };
}

// Async thunks
export const fetchBlogs = createAsyncThunk(
  'blogs/fetchBlogs',
  async (filters: any, { rejectWithValue }) => {
    try {
      const response = await blogApi.getBlogs(filters);
      return response.data;
    } catch (error: any) {
      return rejectWithValue(error.response?.data?.detail || 'Failed to fetch blogs');
    }
  }
);

export const fetchBlog = createAsyncThunk(
  'blogs/fetchBlog',
  async (id: string, { rejectWithValue }) => {
    try {
      const response = await blogApi.getBlog(id);
      return response.data;
    } catch (error: any) {
      return rejectWithValue(error.response?.data?.detail || 'Failed to fetch blog');
    }
  }
);

export const createBlog = createAsyncThunk(
  'blogs/createBlog',
  async (blogData: any, { rejectWithValue }) => {
    try {
      const response = await blogApi.createBlog(blogData);
      return response.data;
    } catch (error: any) {
      return rejectWithValue(error.response?.data?.detail || 'Failed to create blog');
    }
  }
);

export const updateBlog = createAsyncThunk(
  'blogs/updateBlog',
  async ({ id, blogData }: { id: string, blogData: any }, { rejectWithValue }) => {
    try {
      const response = await blogApi.updateBlog(id, blogData);
      return response.data;
    } catch (error: any) {
      return rejectWithValue(error.response?.data?.detail || 'Failed to update blog');
    }
  }
);

export const deleteBlog = createAsyncThunk(
  'blogs/deleteBlog',
  async (id: string, { rejectWithValue }) => {
    try {
      await blogApi.deleteBlog(id);
      return id;
    } catch (error: any) {
      return rejectWithValue(error.response?.data?.detail || 'Failed to delete blog');
    }
  }
);

export const fetchBlogComments = createAsyncThunk(
  'blogs/fetchBlogComments',
  async ({ id, params = {} }: { id: string, params?: any }, { rejectWithValue }) => {
    try {
      const response = await blogApi.getComments(id, params);
      return response.data;
    } catch (error: any) {
      return rejectWithValue(error.response?.data?.detail || 'Failed to fetch comments');
    }
  }
);

export const addComment = createAsyncThunk(
  'blogs/addComment',
  async ({ id, content }: { id: string, content: string }, { rejectWithValue }) => {
    try {
      const response = await blogApi.addComment(id, content);
      return response.data;
    } catch (error: any) {
      return rejectWithValue(error.response?.data?.detail || 'Failed to add comment');
    }
  }
);

export const likeBlog = createAsyncThunk(
  'blogs/likeBlog',
  async (id: string, { rejectWithValue }) => {
    try {
      const response = await blogApi.likeBlog(id);
      return response.data;
    } catch (error: any) {
      return rejectWithValue(error.response?.data?.detail || 'Failed to like blog');
    }
  }
);

export const unlikeBlog = createAsyncThunk(
  'blogs/unlikeBlog',
  async (id: string, { rejectWithValue }) => {
    try {
      await blogApi.unlikeBlog(id);
      return id;
    } catch (error: any) {
      return rejectWithValue(error.response?.data?.detail || 'Failed to unlike blog');
    }
  }
);

export const fetchBlogCategories = createAsyncThunk(
  'blogs/fetchBlogCategories',
  async (_, { rejectWithValue }) => {
    try {
      const response = await categoryApi.getCategories({ is_for_blogs: true });
      return response.data;
    } catch (error: any) {
      return rejectWithValue(error.response?.data?.detail || 'Failed to fetch categories');
    }
  }
);

const initialState: BlogState = {
  blogs: [],
  currentBlog: null,
  comments: [],
  categories: [],
  isLoading: false,
  error: null,
  hasMore: true,
  filters: {
    page: 1,
    per_page: 10,
    sort_by: 'created_at',
    order: 'desc'
  }
};

const blogSlice = createSlice({
  name: 'blogs',
  initialState,
  reducers: {
    clearCurrentBlog: (state) => {
      state.currentBlog = null;
    },
    setFilters: (state, action: PayloadAction<any>) => {
      // If page is 1, reset blogs for a fresh query
      if (action.payload.page === 1 && state.blogs.length > 0) {
        state.blogs = [];
      }
      state.filters = { ...state.filters, ...action.payload };
    },
    clearError: (state) => {
      state.error = null;
    }
  },
  extraReducers: (builder) => {
    // Fetch blogs
    builder.addCase(fetchBlogs.pending, (state) => {
      state.isLoading = true;
      state.error = null;
    });
    builder.addCase(fetchBlogs.fulfilled, (state, action: PayloadAction<any>) => {
      state.isLoading = false;
      // If it's the first page or a new query, replace blogs array
      // Otherwise append to existing array for pagination
      if (state.filters.page === 1) {
        state.blogs = action.payload.items;
      } else {
        state.blogs = [...state.blogs, ...action.payload.items];
      }
      state.hasMore = action.payload.has_more || false;
    });
    builder.addCase(fetchBlogs.rejected, (state, action) => {
      state.isLoading = false;
      state.error = action.payload as string;
    });

    // Fetch single blog
    builder.addCase(fetchBlog.pending, (state) => {
      state.isLoading = true;
      state.error = null;
    });
    builder.addCase(fetchBlog.fulfilled, (state, action) => {
      state.isLoading = false;
      state.currentBlog = action.payload;
    });
    builder.addCase(fetchBlog.rejected, (state, action) => {
      state.isLoading = false;
      state.error = action.payload as string;
    });

    // Create blog
    builder.addCase(createBlog.pending, (state) => {
      state.isLoading = true;
      state.error = null;
    });
    builder.addCase(createBlog.fulfilled, (state, action) => {
      state.isLoading = false;
      state.blogs = [action.payload, ...state.blogs];
    });
    builder.addCase(createBlog.rejected, (state, action) => {
      state.isLoading = false;
      state.error = action.payload as string;
    });

    // Update blog
    builder.addCase(updateBlog.pending, (state) => {
      state.isLoading = true;
      state.error = null;
    });
    builder.addCase(updateBlog.fulfilled, (state, action) => {
      state.isLoading = false;
      state.currentBlog = action.payload;
      
      // Update in blogs array if it exists
      const index = state.blogs.findIndex(blog => blog.id === action.payload.id);
      if (index !== -1) {
        state.blogs[index] = action.payload;
      }
    });
    builder.addCase(updateBlog.rejected, (state, action) => {
      state.isLoading = false;
      state.error = action.payload as string;
    });

    // Delete blog
    builder.addCase(deleteBlog.pending, (state) => {
      state.isLoading = true;
      state.error = null;
    });
    builder.addCase(deleteBlog.fulfilled, (state, action) => {
      state.isLoading = false;
      state.blogs = state.blogs.filter(blog => blog.id !== action.payload);
      if (state.currentBlog && state.currentBlog.id === action.payload) {
        state.currentBlog = null;
      }
    });
    builder.addCase(deleteBlog.rejected, (state, action) => {
      state.isLoading = false;
      state.error = action.payload as string;
    });

    // Fetch blog comments
    builder.addCase(fetchBlogComments.pending, (state) => {
      state.isLoading = true;
      state.error = null;
    });
    builder.addCase(fetchBlogComments.fulfilled, (state, action) => {
      state.isLoading = false;
      state.comments = action.payload;
    });
    builder.addCase(fetchBlogComments.rejected, (state, action) => {
      state.isLoading = false;
      state.error = action.payload as string;
    });

    // Add comment
    builder.addCase(addComment.pending, (state) => {
      state.isLoading = true;
      state.error = null;
    });
    builder.addCase(addComment.fulfilled, (state, action) => {
      state.isLoading = false;
      state.comments = [action.payload, ...state.comments];
    });
    builder.addCase(addComment.rejected, (state, action) => {
      state.isLoading = false;
      state.error = action.payload as string;
    });

    // Like blog
    builder.addCase(likeBlog.fulfilled, (state, action) => {
      if (state.currentBlog) {
        state.currentBlog.like_count += 1;
      }
      // Update like count in blogs array
      const index = state.blogs.findIndex(blog => blog.id === action.payload.blog_id);
      if (index !== -1) {
        state.blogs[index].like_count += 1;
      }
    });

    // Unlike blog
    builder.addCase(unlikeBlog.fulfilled, (state, action) => {
      if (state.currentBlog && state.currentBlog.like_count > 0) {
        state.currentBlog.like_count -= 1;
      }
      // Update like count in blogs array
      const index = state.blogs.findIndex(blog => blog.id === action.payload);
      if (index !== -1 && state.blogs[index].like_count > 0) {
        state.blogs[index].like_count -= 1;
      }
    });

    // Fetch blog categories
    builder.addCase(fetchBlogCategories.pending, (state) => {
      state.error = null;
    });
    builder.addCase(fetchBlogCategories.fulfilled, (state, action) => {
      state.categories = action.payload;
    });
    builder.addCase(fetchBlogCategories.rejected, (state, action) => {
      state.error = action.payload as string;
    });
  }
});

export const { clearCurrentBlog, setFilters, clearError } = blogSlice.actions;
export default blogSlice.reducer;