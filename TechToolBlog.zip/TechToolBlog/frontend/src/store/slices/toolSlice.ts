import { createSlice, createAsyncThunk, PayloadAction } from '@reduxjs/toolkit';
import { toolApi, categoryApi } from '../../services/api';

interface Tool {
  id: string;
  name: string;
  description: string;
  website_url: string;
  pricing_info?: string;
  logo_url?: string;
  features?: any;
  average_rating: number;
  created_at: string;
  updated_at: string;
  categories: Array<any>;
  reviews?: Array<Review>;
  like_count?: number;
}

interface Review {
  id: string;
  user_id: string;
  tool_id: string;
  rating: number;
  content: string;
  created_at: string;
  updated_at: string;
  user: any;
}

interface Category {
  id: string;
  name: string;
  description?: string;
  parent_id?: string;
  is_for_tools: boolean;
  is_for_blogs: boolean;
  created_at: string;
  updated_at: string;
  subcategories?: Category[];
}

interface ToolState {
  tools: Tool[];
  currentTool: Tool | null;
  comparisonTools: Tool[];
  reviews: Review[];
  categories: Category[];
  isLoading: boolean;
  error: string | null;
  hasMore: boolean;
  filters: {
    page: number;
    per_page: number;
    sort_by?: string;
    order?: 'asc' | 'desc';
    category_id?: string;
    search?: string;
    min_rating?: number;
  };
}

// Async thunks
export const fetchTools = createAsyncThunk(
  'tools/fetchTools',
  async (filters: any, { rejectWithValue }) => {
    try {
      const response = await toolApi.getTools(filters);
      return response.data;
    } catch (error: any) {
      return rejectWithValue(error.response?.data?.detail || 'Failed to fetch tools');
    }
  }
);

export const fetchTool = createAsyncThunk(
  'tools/fetchTool',
  async (id: string, { rejectWithValue }) => {
    try {
      const response = await toolApi.getTool(id);
      return response.data;
    } catch (error: any) {
      return rejectWithValue(error.response?.data?.detail || 'Failed to fetch tool');
    }
  }
);

export const createTool = createAsyncThunk(
  'tools/createTool',
  async (toolData: any, { rejectWithValue }) => {
    try {
      const response = await toolApi.createTool(toolData);
      return response.data;
    } catch (error: any) {
      return rejectWithValue(error.response?.data?.detail || 'Failed to create tool');
    }
  }
);

export const updateTool = createAsyncThunk(
  'tools/updateTool',
  async ({ id, toolData }: { id: string, toolData: any }, { rejectWithValue }) => {
    try {
      const response = await toolApi.updateTool(id, toolData);
      return response.data;
    } catch (error: any) {
      return rejectWithValue(error.response?.data?.detail || 'Failed to update tool');
    }
  }
);

export const deleteTool = createAsyncThunk(
  'tools/deleteTool',
  async (id: string, { rejectWithValue }) => {
    try {
      await toolApi.deleteTool(id);
      return id;
    } catch (error: any) {
      return rejectWithValue(error.response?.data?.detail || 'Failed to delete tool');
    }
  }
);

export const fetchToolReviews = createAsyncThunk(
  'tools/fetchToolReviews',
  async ({ id, params = {} }: { id: string, params?: any }, { rejectWithValue }) => {
    try {
      const response = await toolApi.getReviews(id, params);
      return response.data;
    } catch (error: any) {
      return rejectWithValue(error.response?.data?.detail || 'Failed to fetch reviews');
    }
  }
);

export const addReview = createAsyncThunk(
  'tools/addReview',
  async ({ id, rating, content }: { id: string, rating: number, content: string }, { rejectWithValue }) => {
    try {
      const response = await toolApi.addReview(id, rating, content);
      return response.data;
    } catch (error: any) {
      return rejectWithValue(error.response?.data?.detail || 'Failed to add review');
    }
  }
);

export const likeTool = createAsyncThunk(
  'tools/likeTool',
  async (id: string, { rejectWithValue }) => {
    try {
      const response = await toolApi.likeTool(id);
      return response.data;
    } catch (error: any) {
      return rejectWithValue(error.response?.data?.detail || 'Failed to like tool');
    }
  }
);

export const unlikeTool = createAsyncThunk(
  'tools/unlikeTool',
  async (id: string, { rejectWithValue }) => {
    try {
      await toolApi.unlikeTool(id);
      return id;
    } catch (error: any) {
      return rejectWithValue(error.response?.data?.detail || 'Failed to unlike tool');
    }
  }
);

export const compareTools = createAsyncThunk(
  'tools/compareTools',
  async (toolIds: string[], { rejectWithValue }) => {
    try {
      const response = await toolApi.compareTools(toolIds);
      return response.data;
    } catch (error: any) {
      return rejectWithValue(error.response?.data?.detail || 'Failed to compare tools');
    }
  }
);

export const getCurrentComparison = createAsyncThunk(
  'tools/getCurrentComparison',
  async (_, { rejectWithValue }) => {
    try {
      const response = await toolApi.getCurrentComparison();
      return response.data;
    } catch (error: any) {
      return rejectWithValue(error.response?.data?.detail || 'Failed to get current comparison');
    }
  }
);

export const searchTools = createAsyncThunk(
  'tools/searchTools',
  async (query: string, { rejectWithValue }) => {
    try {
      const response = await toolApi.searchTools(query);
      return response.data;
    } catch (error: any) {
      return rejectWithValue(error.response?.data?.detail || 'Failed to search tools');
    }
  }
);

export const getTrendingTools = createAsyncThunk(
  'tools/getTrendingTools',
  async (limit: number = 10, { rejectWithValue }) => {
    try {
      const response = await toolApi.getTrendingTools(limit);
      return response.data;
    } catch (error: any) {
      return rejectWithValue(error.response?.data?.detail || 'Failed to get trending tools');
    }
  }
);

interface UploadToolsCSVResult {
  total_imported: number;
  failed_entries: Array<{
    row: number;
    reason: string;
    data?: Record<string, any>;
  }>;
  message: string;
}

export const uploadToolsCSV = createAsyncThunk<UploadToolsCSVResult, FormData>(
  'tools/uploadToolsCSV',
  async (formData, { rejectWithValue, dispatch }) => {
    try {
      // Check if a file is included in the formData
      const file = formData.get('file');
      if (!file || !(file instanceof File)) {
        return rejectWithValue('No file provided or invalid file');
      }
      
      // Validate file type
      if (!file.name.endsWith('.csv')) {
        return rejectWithValue('Only CSV files are accepted');
      }
      
      // Make the API call
      const response = await toolApi.uploadToolsCSV(file);
      
      // If upload succeeded, refresh the tools list
      if (response.data.total_imported > 0) {
        // Refresh the tools list with current filters
        dispatch(fetchTools({
          page: 1,
          per_page: 10,
          sort_by: 'created_at',
          order: 'desc'
        }));
      }
      
      return response.data;
    } catch (error: any) {
      // Handle specific error cases
      if (error.response?.status === 413) {
        return rejectWithValue('The CSV file is too large. Please try a smaller file.');
      }
      
      if (error.response?.status === 403) {
        return rejectWithValue('You do not have permission to upload tools. Admin access is required.');
      }
      
      // Try to extract detailed error information from the response
      const errorMessage = error.response?.data?.detail || 
                          error.response?.data?.message || 
                          error.message || 
                          'Failed to upload CSV';
      
      return rejectWithValue(errorMessage);
    }
  }
);

export const fetchToolCategories = createAsyncThunk(
  'tools/fetchToolCategories',
  async (_, { rejectWithValue }) => {
    try {
      const response = await categoryApi.getCategories({ is_for_tools: true });
      return response.data;
    } catch (error: any) {
      return rejectWithValue(error.response?.data?.detail || 'Failed to fetch categories');
    }
  }
);

const initialState: ToolState = {
  tools: [],
  currentTool: null,
  comparisonTools: [],
  reviews: [],
  categories: [],
  isLoading: false,
  error: null,
  hasMore: true,
  filters: {
    page: 1,
    per_page: 10,
    sort_by: 'average_rating',
    order: 'desc'
  }
};

const toolSlice = createSlice({
  name: 'tools',
  initialState,
  reducers: {
    clearCurrentTool: (state) => {
      state.currentTool = null;
    },
    setFilters: (state, action: PayloadAction<any>) => {
      // If page is 1, reset tools for a fresh query
      if (action.payload.page === 1 && state.tools.length > 0) {
        state.tools = [];
      }
      state.filters = { ...state.filters, ...action.payload };
    },
    addToComparison: (state, action: PayloadAction<Tool>) => {
      // Check if the tool is already in the comparison list
      const existingIndex = state.comparisonTools.findIndex(tool => tool.id === action.payload.id);
      
      // If not in the list and not exceeding 5 tools, add it
      if (existingIndex === -1 && state.comparisonTools.length < 5) {
        state.comparisonTools.push(action.payload);
      }
    },
    removeFromComparison: (state, action: PayloadAction<string>) => {
      state.comparisonTools = state.comparisonTools.filter(tool => tool.id !== action.payload);
    },
    clearComparison: (state) => {
      state.comparisonTools = [];
    },
    clearError: (state) => {
      state.error = null;
    }
  },
  extraReducers: (builder) => {
    // Fetch tools
    builder.addCase(fetchTools.pending, (state) => {
      state.isLoading = true;
      state.error = null;
    });
    builder.addCase(fetchTools.fulfilled, (state, action: PayloadAction<any>) => {
      state.isLoading = false;
      // If it's the first page or a new query, replace tools array
      // Otherwise append to existing array for pagination
      if (state.filters.page === 1) {
        state.tools = action.payload.items;
      } else {
        state.tools = [...state.tools, ...action.payload.items];
      }
      state.hasMore = action.payload.has_more || false;
    });
    builder.addCase(fetchTools.rejected, (state, action) => {
      state.isLoading = false;
      state.error = action.payload as string;
    });

    // Fetch single tool
    builder.addCase(fetchTool.pending, (state) => {
      state.isLoading = true;
      state.error = null;
    });
    builder.addCase(fetchTool.fulfilled, (state, action) => {
      state.isLoading = false;
      state.currentTool = action.payload;
    });
    builder.addCase(fetchTool.rejected, (state, action) => {
      state.isLoading = false;
      state.error = action.payload as string;
    });

    // Create tool
    builder.addCase(createTool.pending, (state) => {
      state.isLoading = true;
      state.error = null;
    });
    builder.addCase(createTool.fulfilled, (state, action) => {
      state.isLoading = false;
      state.tools = [action.payload, ...state.tools];
    });
    builder.addCase(createTool.rejected, (state, action) => {
      state.isLoading = false;
      state.error = action.payload as string;
    });

    // Update tool
    builder.addCase(updateTool.pending, (state) => {
      state.isLoading = true;
      state.error = null;
    });
    builder.addCase(updateTool.fulfilled, (state, action) => {
      state.isLoading = false;
      state.currentTool = action.payload;
      
      // Update in tools array if it exists
      const index = state.tools.findIndex(tool => tool.id === action.payload.id);
      if (index !== -1) {
        state.tools[index] = action.payload;
      }
    });
    builder.addCase(updateTool.rejected, (state, action) => {
      state.isLoading = false;
      state.error = action.payload as string;
    });

    // Delete tool
    builder.addCase(deleteTool.pending, (state) => {
      state.isLoading = true;
      state.error = null;
    });
    builder.addCase(deleteTool.fulfilled, (state, action) => {
      state.isLoading = false;
      state.tools = state.tools.filter(tool => tool.id !== action.payload);
      if (state.currentTool && state.currentTool.id === action.payload) {
        state.currentTool = null;
      }
      // Also remove from comparison if present
      state.comparisonTools = state.comparisonTools.filter(tool => tool.id !== action.payload);
    });
    builder.addCase(deleteTool.rejected, (state, action) => {
      state.isLoading = false;
      state.error = action.payload as string;
    });

    // Fetch tool reviews
    builder.addCase(fetchToolReviews.pending, (state) => {
      state.isLoading = true;
      state.error = null;
    });
    builder.addCase(fetchToolReviews.fulfilled, (state, action) => {
      state.isLoading = false;
      state.reviews = action.payload;
    });
    builder.addCase(fetchToolReviews.rejected, (state, action) => {
      state.isLoading = false;
      state.error = action.payload as string;
    });

    // Add review
    builder.addCase(addReview.pending, (state) => {
      state.isLoading = true;
      state.error = null;
    });
    builder.addCase(addReview.fulfilled, (state, action) => {
      state.isLoading = false;
      state.reviews = [action.payload, ...state.reviews];
      
      // Update tool average rating if currentTool is set
      if (state.currentTool && action.payload.tool_id === state.currentTool.id) {
        // This assumes the API response includes the updated average_rating
        // If not, we would need to calculate it here
        if (action.payload.updated_average_rating) {
          state.currentTool.average_rating = action.payload.updated_average_rating;
        }
      }
    });
    builder.addCase(addReview.rejected, (state, action) => {
      state.isLoading = false;
      state.error = action.payload as string;
    });

    // Like tool
    builder.addCase(likeTool.fulfilled, (state, action) => {
      if (state.currentTool) {
        state.currentTool.like_count = (state.currentTool.like_count || 0) + 1;
      }
      // Update like count in tools array
      const index = state.tools.findIndex(tool => tool.id === action.payload.tool_id);
      if (index !== -1) {
        state.tools[index].like_count = (state.tools[index].like_count || 0) + 1;
      }
    });

    // Unlike tool
    builder.addCase(unlikeTool.fulfilled, (state, action) => {
      if (state.currentTool && state.currentTool.like_count && state.currentTool.like_count > 0) {
        state.currentTool.like_count -= 1;
      }
      // Update like count in tools array
      const index = state.tools.findIndex(tool => tool.id === action.payload);
      if (index !== -1 && state.tools[index].like_count && state.tools[index].like_count > 0) {
        state.tools[index].like_count -= 1;
      }
    });

    // Compare tools
    builder.addCase(compareTools.pending, (state) => {
      state.isLoading = true;
      state.error = null;
    });
    builder.addCase(compareTools.fulfilled, (state, action) => {
      state.isLoading = false;
      state.comparisonTools = action.payload;
    });
    builder.addCase(compareTools.rejected, (state, action) => {
      state.isLoading = false;
      state.error = action.payload as string;
    });

    // Get current comparison
    builder.addCase(getCurrentComparison.pending, (state) => {
      state.isLoading = true;
      state.error = null;
    });
    builder.addCase(getCurrentComparison.fulfilled, (state, action) => {
      state.isLoading = false;
      state.comparisonTools = action.payload;
    });
    builder.addCase(getCurrentComparison.rejected, (state, action) => {
      state.isLoading = false;
      state.error = action.payload as string;
    });

    // Search tools
    builder.addCase(searchTools.pending, (state) => {
      state.isLoading = true;
      state.error = null;
    });
    builder.addCase(searchTools.fulfilled, (state, action) => {
      state.isLoading = false;
      state.tools = action.payload;
      state.hasMore = false; // Search results typically don't have pagination
    });
    builder.addCase(searchTools.rejected, (state, action) => {
      state.isLoading = false;
      state.error = action.payload as string;
    });

    // Get trending tools
    builder.addCase(getTrendingTools.pending, (state) => {
      state.isLoading = true;
      state.error = null;
    });
    builder.addCase(getTrendingTools.fulfilled, (state, action) => {
      state.isLoading = false;
      state.tools = action.payload;
      state.hasMore = false; // Trending results typically don't have pagination
    });
    builder.addCase(getTrendingTools.rejected, (state, action) => {
      state.isLoading = false;
      state.error = action.payload as string;
    });

    // Upload tools CSV
    builder.addCase(uploadToolsCSV.pending, (state) => {
      state.isLoading = true;
      state.error = null;
    });
    builder.addCase(uploadToolsCSV.fulfilled, (state) => {
      state.isLoading = false;
      // Typically, we would fetch all tools again after a successful upload
      // But this depends on the API response structure
    });
    builder.addCase(uploadToolsCSV.rejected, (state, action) => {
      state.isLoading = false;
      state.error = action.payload as string;
    });

    // Fetch tool categories
    builder.addCase(fetchToolCategories.pending, (state) => {
      state.error = null;
    });
    builder.addCase(fetchToolCategories.fulfilled, (state, action) => {
      state.categories = action.payload;
    });
    builder.addCase(fetchToolCategories.rejected, (state, action) => {
      state.error = action.payload as string;
    });
  }
});

export const { 
  clearCurrentTool, 
  setFilters, 
  addToComparison, 
  removeFromComparison, 
  clearComparison,
  clearError 
} = toolSlice.actions;

export default toolSlice.reducer;