import { createSlice, createAsyncThunk, PayloadAction } from '@reduxjs/toolkit';
import { authApi } from '../../services/api';

interface User {
  id: string;
  username: string;
  email: string;
  full_name?: string;
  role: string;
  is_active: boolean;
  is_verified: boolean;
}

interface AuthState {
  user: User | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  error: string | null;
  twoFactorRequired: boolean;
  twoFactorEmail: string | null;
}

interface LoginCredentials {
  username: string;
  password: string;
}

interface RegisterData {
  username: string;
  email: string;
  password: string;
  confirm_password: string;
  full_name?: string;
}

interface TwoFactorData {
  email: string;
  verification_code: string;
}

// Async thunks
export const login = createAsyncThunk(
  'auth/login',
  async (credentials: LoginCredentials, { rejectWithValue }) => {
    try {
      const response = await authApi.login(credentials.username, credentials.password);
      localStorage.setItem('token', response.data.access_token);
      return response.data;
    } catch (error: any) {
      if (error.response?.status === 403 && error.response?.data?.detail === 'Two-factor authentication required') {
        return {
          twoFactorRequired: true,
          email: error.response.data.email || credentials.username
        };
      }
      return rejectWithValue(error.response?.data?.detail || 'Login failed');
    }
  }
);

export const register = createAsyncThunk(
  'auth/register',
  async (userData: RegisterData, { rejectWithValue }) => {
    try {
      const response = await authApi.register(userData);
      localStorage.setItem('token', response.data.access_token);
      return response.data;
    } catch (error: any) {
      return rejectWithValue(error.response?.data?.detail || 'Registration failed');
    }
  }
);

export const verifyTwoFactor = createAsyncThunk(
  'auth/verifyTwoFactor',
  async (data: TwoFactorData, { rejectWithValue }) => {
    try {
      const response = await authApi.verifyTwoFactor(data.email, data.verification_code);
      localStorage.setItem('token', response.data.access_token);
      return response.data;
    } catch (error: any) {
      return rejectWithValue(error.response?.data?.detail || 'Verification failed');
    }
  }
);

export const requestVerificationCode = createAsyncThunk(
  'auth/requestVerificationCode',
  async (email: string, { rejectWithValue }) => {
    try {
      const response = await authApi.requestVerificationCode(email);
      return response.data;
    } catch (error: any) {
      return rejectWithValue(error.response?.data?.detail || 'Failed to send verification code');
    }
  }
);

export const checkAuth = createAsyncThunk(
  'auth/checkAuth',
  async (_, { rejectWithValue }) => {
    try {
      const token = localStorage.getItem('token');
      if (!token) {
        return rejectWithValue('No token found');
      }
      
      const response = await authApi.getCurrentUser();
      return response.data;
    } catch (error: any) {
      localStorage.removeItem('token');
      return rejectWithValue(error.response?.data?.detail || 'Authentication failed');
    }
  }
);

export const logout = createAsyncThunk(
  'auth/logout',
  async (_, { rejectWithValue }) => {
    try {
      localStorage.removeItem('token');
      return true;
    } catch (error: any) {
      return rejectWithValue('Logout failed');
    }
  }
);

const initialState: AuthState = {
  user: null,
  isAuthenticated: false,
  isLoading: false,
  error: null,
  twoFactorRequired: false,
  twoFactorEmail: null
};

const authSlice = createSlice({
  name: 'auth',
  initialState,
  reducers: {
    clearError: (state) => {
      state.error = null;
    },
    resetTwoFactorState: (state) => {
      state.twoFactorRequired = false;
      state.twoFactorEmail = null;
    }
  },
  extraReducers: (builder) => {
    // Login
    builder.addCase(login.pending, (state) => {
      state.isLoading = true;
      state.error = null;
    });
    builder.addCase(login.fulfilled, (state, action: PayloadAction<any>) => {
      state.isLoading = false;
      if (action.payload.twoFactorRequired) {
        state.twoFactorRequired = true;
        state.twoFactorEmail = action.payload.email;
        state.isAuthenticated = false;
      } else {
        state.user = action.payload.user;
        state.isAuthenticated = true;
        state.twoFactorRequired = false;
        state.twoFactorEmail = null;
      }
    });
    builder.addCase(login.rejected, (state, action) => {
      state.isLoading = false;
      state.error = action.payload as string;
    });

    // Register
    builder.addCase(register.pending, (state) => {
      state.isLoading = true;
      state.error = null;
    });
    builder.addCase(register.fulfilled, (state, action) => {
      state.isLoading = false;
      state.user = action.payload.user;
      state.isAuthenticated = true;
    });
    builder.addCase(register.rejected, (state, action) => {
      state.isLoading = false;
      state.error = action.payload as string;
    });

    // Verify Two Factor
    builder.addCase(verifyTwoFactor.pending, (state) => {
      state.isLoading = true;
      state.error = null;
    });
    builder.addCase(verifyTwoFactor.fulfilled, (state, action) => {
      state.isLoading = false;
      state.user = action.payload.user;
      state.isAuthenticated = true;
      state.twoFactorRequired = false;
      state.twoFactorEmail = null;
    });
    builder.addCase(verifyTwoFactor.rejected, (state, action) => {
      state.isLoading = false;
      state.error = action.payload as string;
    });

    // Request Verification Code
    builder.addCase(requestVerificationCode.pending, (state) => {
      state.isLoading = true;
      state.error = null;
    });
    builder.addCase(requestVerificationCode.fulfilled, (state) => {
      state.isLoading = false;
    });
    builder.addCase(requestVerificationCode.rejected, (state, action) => {
      state.isLoading = false;
      state.error = action.payload as string;
    });

    // Check Auth
    builder.addCase(checkAuth.pending, (state) => {
      state.isLoading = true;
      state.error = null;
    });
    builder.addCase(checkAuth.fulfilled, (state, action) => {
      state.isLoading = false;
      state.user = action.payload;
      state.isAuthenticated = true;
    });
    builder.addCase(checkAuth.rejected, (state) => {
      state.isLoading = false;
      state.user = null;
      state.isAuthenticated = false;
    });

    // Logout
    builder.addCase(logout.fulfilled, (state) => {
      state.user = null;
      state.isAuthenticated = false;
      state.twoFactorRequired = false;
      state.twoFactorEmail = null;
    });
  }
});

export const { clearError, resetTwoFactorState } = authSlice.actions;
export default authSlice.reducer;