import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAppDispatch, useAppSelector } from '../../store/hooks';
import { fetchBlogCategories } from '../../store/slices/blogSlice';

// Interface for blog data
interface BlogData {
  id?: string;
  title: string;
  content: string;
  excerpt?: string;
  featured_image?: string;
  category_ids: string[];
  status: 'draft' | 'published';
}

interface BlogEditorProps {
  initialBlog?: Partial<BlogData>;
  onSave: (blogData: BlogData) => Promise<{ id: string; slug: string }>;
  isSaving: boolean;
}

const BlogEditor: React.FC<BlogEditorProps> = ({ initialBlog, onSave, isSaving }) => {
  const navigate = useNavigate();
  const dispatch = useAppDispatch();
  const { categories } = useAppSelector((state) => state.blogs);
  
  // Initialize blog data from props or default values
  const [blogData, setBlogData] = useState<BlogData>({
    title: initialBlog?.title || '',
    content: initialBlog?.content || '',
    excerpt: initialBlog?.excerpt || '',
    featured_image: initialBlog?.featured_image || '',
    category_ids: initialBlog?.category_ids || [],
    status: initialBlog?.status || 'draft'
  });
  
  const [previewMode, setPreviewMode] = useState(false);
  const [errors, setErrors] = useState<Record<string, string>>({});
  
  // Fetch categories on mount
  useEffect(() => {
    dispatch(fetchBlogCategories());
  }, [dispatch]);
  
  // Handle form field changes
  const handleChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>
  ) => {
    const { name, value } = e.target;
    setBlogData((prev) => ({ ...prev, [name]: value }));
    
    // Clear error for this field if it exists
    if (errors[name]) {
      setErrors((prev) => {
        const newErrors = { ...prev };
        delete newErrors[name];
        return newErrors;
      });
    }
  };
  
  // Handle category selection with multiple select
  const handleCategoryChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const options = e.target.options;
    const selectedCategories: string[] = [];
    
    for (let i = 0; i < options.length; i++) {
      if (options[i].selected) {
        selectedCategories.push(options[i].value);
      }
    }
    
    setBlogData((prev) => ({ ...prev, category_ids: selectedCategories }));
    
    // Clear error for categories if it exists
    if (errors.category_ids) {
      setErrors((prev) => {
        const newErrors = { ...prev };
        delete newErrors.category_ids;
        return newErrors;
      });
    }
  };
  
  // Handle featured image upload
  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      // In a real implementation, we would upload the file to a server
      // and then set the URL returned from the server
      const file = e.target.files[0];
      const reader = new FileReader();
      
      reader.onloadend = () => {
        setBlogData((prev) => ({ 
          ...prev, 
          featured_image: reader.result as string 
        }));
      };
      
      reader.readAsDataURL(file);
    }
  };
  
  // Validate the form before submission
  const validateForm = (): boolean => {
    const newErrors: Record<string, string> = {};
    
    if (!blogData.title.trim()) {
      newErrors.title = 'Title is required';
    }
    
    if (!blogData.content.trim()) {
      newErrors.content = 'Content is required';
    }
    
    if (blogData.category_ids.length === 0) {
      newErrors.category_ids = 'Please select at least one category';
    }
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };
  
  // Handle form submission
  const handleSubmit = async (e: React.FormEvent, saveAsDraft: boolean = false) => {
    e.preventDefault();
    
    // Set status based on saveAsDraft flag
    const dataToSave = {
      ...blogData,
      status: saveAsDraft ? 'draft' : 'published'
    };
    
    // Validate only if publishing (not for drafts)
    if (!saveAsDraft && !validateForm()) {
      return;
    }
    
    try {
      const result = await onSave(dataToSave);
      // Navigate to the new blog post on success
      navigate(`/blogs/${result.slug}`);
    } catch (error) {
      // Error handling is done in the parent component
    }
  };
  
  // Toggle between edit and preview modes
  const togglePreview = () => {
    setPreviewMode(!previewMode);
  };
  
  return (
    <div className="bg-white rounded-lg shadow-md p-6">
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-2xl font-bold">
          {initialBlog?.id ? 'Edit Blog Post' : 'Create New Blog Post'}
        </h2>
        
        <div className="flex items-center space-x-4">
          <button
            type="button"
            onClick={togglePreview}
            className="px-4 py-2 border border-gray-300 rounded-md text-sm font-medium text-gray-700 bg-white hover:bg-gray-50"
          >
            {previewMode ? 'Edit' : 'Preview'}
          </button>
          
          <button
            type="button"
            onClick={(e) => handleSubmit(e, true)}
            disabled={isSaving}
            className="px-4 py-2 border border-gray-300 rounded-md text-sm font-medium text-gray-700 bg-white hover:bg-gray-50 disabled:opacity-50"
          >
            Save Draft
          </button>
          
          <button
            type="button"
            onClick={(e) => handleSubmit(e, false)}
            disabled={isSaving}
            className="px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 disabled:opacity-50"
          >
            {isSaving ? (
              <>
                <svg
                  className="animate-spin -ml-1 mr-2 h-4 w-4 text-white inline"
                  xmlns="http://www.w3.org/2000/svg"
                  fill="none"
                  viewBox="0 0 24 24"
                >
                  <circle
                    className="opacity-25"
                    cx="12"
                    cy="12"
                    r="10"
                    stroke="currentColor"
                    strokeWidth="4"
                  ></circle>
                  <path
                    className="opacity-75"
                    fill="currentColor"
                    d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"
                  ></path>
                </svg>
                Saving...
              </>
            ) : (
              'Publish'
            )}
          </button>
        </div>
      </div>
      
      {previewMode ? (
        // Preview Mode
        <div>
          <h1 className="text-3xl font-bold mb-4">{blogData.title || 'Untitled Blog Post'}</h1>
          
          {blogData.featured_image && (
            <div className="mb-6">
              <img
                src={blogData.featured_image}
                alt={blogData.title}
                className="w-full h-64 object-cover rounded-lg"
              />
            </div>
          )}
          
          <div className="prose max-w-none blog-content">
            {/* In a real implementation, we would use a markdown or rich text renderer here */}
            <div dangerouslySetInnerHTML={{ __html: blogData.content }} />
          </div>
        </div>
      ) : (
        // Edit Mode
        <form>
          <div className="space-y-6">
            {/* Title Input */}
            <div>
              <label htmlFor="title" className="block text-sm font-medium text-gray-700">
                Title <span className="text-red-500">*</span>
              </label>
              <input
                type="text"
                id="title"
                name="title"
                value={blogData.title}
                onChange={handleChange}
                className={`mt-1 block w-full shadow-sm sm:text-sm rounded-md ${
                  errors.title ? 'border-red-300 focus:ring-red-500 focus:border-red-500' : 'border-gray-300 focus:ring-blue-500 focus:border-blue-500'
                }`}
                placeholder="Enter blog title"
              />
              {errors.title && (
                <p className="mt-2 text-sm text-red-600">{errors.title}</p>
              )}
            </div>
            
            {/* Featured Image Upload */}
            <div>
              <label htmlFor="featured_image" className="block text-sm font-medium text-gray-700">
                Featured Image
              </label>
              <div className="mt-1 flex items-center">
                <input
                  type="file"
                  id="featured_image"
                  accept="image/*"
                  onChange={handleImageUpload}
                  className="sr-only"
                />
                <label
                  htmlFor="featured_image"
                  className="relative cursor-pointer bg-white py-2 px-3 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 hover:bg-gray-50 focus-within:outline-none focus-within:ring-2 focus-within:ring-offset-2 focus-within:ring-blue-500"
                >
                  <span>Upload Image</span>
                </label>
                {blogData.featured_image && (
                  <div className="ml-4 flex items-center">
                    <img
                      src={blogData.featured_image}
                      alt="Featured"
                      className="h-12 w-12 object-cover rounded"
                    />
                    <button
                      type="button"
                      onClick={() => setBlogData((prev) => ({ ...prev, featured_image: '' }))}
                      className="ml-2 text-red-600 hover:text-red-800"
                    >
                      Remove
                    </button>
                  </div>
                )}
              </div>
            </div>
            
            {/* Categories Selection */}
            <div>
              <label htmlFor="categories" className="block text-sm font-medium text-gray-700">
                Categories <span className="text-red-500">*</span>
              </label>
              <select
                id="categories"
                name="categories"
                multiple
                size={4}
                value={blogData.category_ids}
                onChange={handleCategoryChange}
                className={`mt-1 block w-full py-2 px-3 shadow-sm sm:text-sm rounded-md ${
                  errors.category_ids ? 'border-red-300 focus:ring-red-500 focus:border-red-500' : 'border-gray-300 focus:ring-blue-500 focus:border-blue-500'
                }`}
              >
                {categories.map((category) => (
                  <option key={category.id} value={category.id}>
                    {category.name}
                  </option>
                ))}
              </select>
              <p className="mt-1 text-sm text-gray-500">
                Hold Ctrl (or Cmd) to select multiple categories
              </p>
              {errors.category_ids && (
                <p className="mt-2 text-sm text-red-600">{errors.category_ids}</p>
              )}
            </div>
            
            {/* Excerpt */}
            <div>
              <label htmlFor="excerpt" className="block text-sm font-medium text-gray-700">
                Excerpt
              </label>
              <textarea
                id="excerpt"
                name="excerpt"
                rows={2}
                value={blogData.excerpt}
                onChange={handleChange}
                className="mt-1 block w-full shadow-sm sm:text-sm border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500"
                placeholder="Brief summary of the blog post (optional)"
              ></textarea>
            </div>
            
            {/* Content */}
            <div>
              <label htmlFor="content" className="block text-sm font-medium text-gray-700">
                Content <span className="text-red-500">*</span>
              </label>
              <textarea
                id="content"
                name="content"
                rows={12}
                value={blogData.content}
                onChange={handleChange}
                className={`mt-1 block w-full shadow-sm sm:text-sm rounded-md ${
                  errors.content ? 'border-red-300 focus:ring-red-500 focus:border-red-500' : 'border-gray-300 focus:ring-blue-500 focus:border-blue-500'
                }`}
                placeholder="Write your blog content here..."
              ></textarea>
              {errors.content && (
                <p className="mt-2 text-sm text-red-600">{errors.content}</p>
              )}
              <p className="mt-1 text-sm text-gray-500">
                HTML tags are supported for formatting.
              </p>
            </div>
          </div>
        </form>
      )}
    </div>
  );
};

export default BlogEditor;