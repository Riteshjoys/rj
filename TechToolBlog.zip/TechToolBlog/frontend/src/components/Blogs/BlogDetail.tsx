import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAppSelector, useAppDispatch } from '../../store/hooks';
import { fetchBlog, fetchBlogComments, likeBlog, unlikeBlog, addComment, deleteBlog } from '../../store/slices/blogSlice';
import { format } from 'date-fns';
import { Helmet } from 'react-helmet-async';

interface BlogDetailProps {
  blogId: string;
}

const BlogDetail: React.FC<BlogDetailProps> = ({ blogId }) => {
  const { currentBlog, comments, isLoading, error } = useAppSelector(state => state.blogs);
  const { user, isAuthenticated } = useAppSelector(state => state.auth);
  const dispatch = useAppDispatch();
  const navigate = useNavigate();
  
  const [commentText, setCommentText] = useState('');
  const [liked, setLiked] = useState(false);
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);
  
  // Fetch blog and comments
  useEffect(() => {
    dispatch(fetchBlog(blogId));
    dispatch(fetchBlogComments({ id: blogId }));
  }, [blogId, dispatch]);
  
  // Format date for display
  const formatDate = (dateString: string) => {
    try {
      return format(new Date(dateString), 'MMM d, yyyy');
    } catch (error) {
      return 'Invalid date';
    }
  };
  
  // Handle like/unlike
  const handleLikeToggle = () => {
    if (!isAuthenticated) {
      navigate('/login');
      return;
    }
    
    if (liked) {
      dispatch(unlikeBlog(blogId));
      setLiked(false);
    } else {
      dispatch(likeBlog(blogId));
      setLiked(true);
    }
  };
  
  // Handle comment submission
  const handleCommentSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!commentText.trim()) return;
    
    dispatch(addComment({ id: blogId, content: commentText }));
    setCommentText('');
  };
  
  // Handle blog deletion
  const handleDelete = () => {
    dispatch(deleteBlog(blogId)).then(() => {
      navigate('/blogs');
    });
  };
  
  if (isLoading && !currentBlog) {
    return (
      <div className="flex justify-center items-center min-h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-500"></div>
      </div>
    );
  }
  
  if (error || !currentBlog) {
    return (
      <div className="py-10 text-center">
        <h2 className="text-2xl font-bold text-red-600 mb-4">
          {error || "Failed to load the blog post"}
        </h2>
        <button 
          onClick={() => dispatch(fetchBlog(blogId))}
          className="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700"
        >
          Try Again
        </button>
      </div>
    );
  }
  
  return (
    <>
      <Helmet>
        <title>{currentBlog.title} | ToolBlog</title>
        <meta name="description" content={currentBlog.excerpt || currentBlog.content.substring(0, 160)} />
      </Helmet>
      
      <article className="max-w-4xl mx-auto">
        {/* Blog Header */}
        <header className="mb-8">
          {/* Categories */}
          {currentBlog.categories.length > 0 && (
            <div className="flex flex-wrap gap-2 mb-4">
              {currentBlog.categories.map(category => (
                <Link 
                  key={category.id}
                  to={`/blogs?category=${category.id}`}
                  className="text-sm font-medium bg-blue-100 text-blue-800 px-3 py-1 rounded-full hover:bg-blue-200"
                >
                  {category.name}
                </Link>
              ))}
            </div>
          )}
          
          {/* Title */}
          <h1 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
            {currentBlog.title}
          </h1>
          
          {/* Author and Date */}
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center">
              <img
                className="h-10 w-10 rounded-full mr-3"
                src={`https://ui-avatars.com/api/?name=${encodeURIComponent(currentBlog.author.username)}&background=random`}
                alt={currentBlog.author.username}
              />
              <div>
                <p className="font-medium text-gray-900">{currentBlog.author.username}</p>
                <time className="text-sm text-gray-500">
                  {currentBlog.published_at ? formatDate(currentBlog.published_at) : formatDate(currentBlog.created_at)}
                </time>
              </div>
            </div>
            
            {/* Stats */}
            <div className="flex space-x-4 text-gray-500">
              <div className="flex items-center">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-1" viewBox="0 0 20 20" fill="currentColor">
                  <path d="M10 12a2 2 0 100-4 2 2 0 000 4z" />
                  <path fillRule="evenodd" d="M.458 10C1.732 5.943 5.522 3 10 3s8.268 2.943 9.542 7c-1.274 4.057-5.064 7-9.542 7S1.732 14.057.458 10zM14 10a4 4 0 11-8 0 4 4 0 018 0z" clipRule="evenodd" />
                </svg>
                {currentBlog.view_count}
              </div>
              <button 
                onClick={handleLikeToggle}
                className={`flex items-center ${liked ? 'text-blue-600' : ''}`}
                disabled={!isAuthenticated}
              >
                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-1" viewBox="0 0 20 20" fill="currentColor">
                  <path d="M2 10.5a1.5 1.5 0 113 0v6a1.5 1.5 0 01-3 0v-6zM6 10.333v5.43a2 2 0 001.106 1.79l.05.025A4 4 0 008.943 18h5.416a2 2 0 001.962-1.608l1.2-6A2 2 0 0015.56 8H12V4a2 2 0 00-2-2 1 1 0 00-1 1v.667a4 4 0 01-.8 2.4L6.8 7.933a4 4 0 00-.8 2.4z" />
                </svg>
                {currentBlog.like_count}
              </button>
            </div>
          </div>
          
          {/* Featured Image */}
          {currentBlog.featured_image && (
            <div className="mb-6">
              <img
                src={currentBlog.featured_image}
                alt={currentBlog.title}
                className="w-full h-auto rounded-lg"
                onError={(e) => {
                  (e.target as HTMLImageElement).src = 'https://via.placeholder.com/1200x600?text=Image+Not+Available';
                }}
              />
            </div>
          )}
        </header>
        
        {/* Blog Content */}
        <div className="prose prose-lg max-w-none mb-10 blog-content">
          {currentBlog.content_json ? (
            <div dangerouslySetInnerHTML={{ __html: JSON.parse(currentBlog.content_json).html || currentBlog.content }} />
          ) : (
            <div dangerouslySetInnerHTML={{ __html: currentBlog.content }} />
          )}
        </div>
        
        {/* Author Actions */}
        {isAuthenticated && user && (user.id === currentBlog.author_id || user.role === 'admin') && (
          <div className="border-t border-gray-200 pt-6 mb-10">
            <div className="flex justify-end space-x-4">
              <Link 
                to={`/blogs/edit/${currentBlog.id}`}
                className="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700"
              >
                Edit
              </Link>
              <button 
                onClick={() => setShowDeleteConfirm(true)}
                className="px-4 py-2 bg-red-600 text-white rounded hover:bg-red-700"
              >
                Delete
              </button>
            </div>
            
            {/* Delete Confirmation Modal */}
            {showDeleteConfirm && (
              <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
                <div className="bg-white p-6 rounded-lg max-w-md mx-4">
                  <h3 className="text-xl font-bold mb-4">Confirm Deletion</h3>
                  <p className="mb-6">Are you sure you want to delete this blog post? This action cannot be undone.</p>
                  <div className="flex justify-end space-x-4">
                    <button 
                      onClick={() => setShowDeleteConfirm(false)}
                      className="px-4 py-2 bg-gray-200 text-gray-800 rounded hover:bg-gray-300"
                    >
                      Cancel
                    </button>
                    <button 
                      onClick={handleDelete}
                      className="px-4 py-2 bg-red-600 text-white rounded hover:bg-red-700"
                    >
                      Delete
                    </button>
                  </div>
                </div>
              </div>
            )}
          </div>
        )}
        
        {/* Comments Section */}
        <section className="mt-10 border-t border-gray-200 pt-10">
          <h2 className="text-2xl font-bold mb-6">Comments ({comments.length})</h2>
          
          {/* Comment Form */}
          {isAuthenticated ? (
            <form onSubmit={handleCommentSubmit} className="mb-8">
              <div className="mb-4">
                <label htmlFor="comment" className="block text-gray-700 mb-2">
                  Add a comment
                </label>
                <textarea
                  id="comment"
                  rows={4}
                  className="w-full p-3 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                  value={commentText}
                  onChange={(e) => setCommentText(e.target.value)}
                  placeholder="Share your thoughts..."
                ></textarea>
              </div>
              <button
                type="submit"
                className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-opacity-50"
                disabled={isLoading || !commentText.trim()}
              >
                Post Comment
              </button>
            </form>
          ) : (
            <div className="bg-gray-50 p-4 rounded-md mb-8">
              <p className="text-gray-700">
                <Link to="/login" className="text-blue-600 hover:underline">Log in</Link> to leave a comment.
              </p>
            </div>
          )}
          
          {/* Comments List */}
          <div className="space-y-6">
            {comments.length > 0 ? (
              comments.map(comment => (
                <div key={comment.id} className="border-b border-gray-200 pb-6">
                  <div className="flex items-center mb-2">
                    <img
                      className="h-8 w-8 rounded-full mr-2"
                      src={`https://ui-avatars.com/api/?name=${encodeURIComponent(comment.user.username)}&background=random`}
                      alt={comment.user.username}
                    />
                    <div>
                      <p className="font-medium text-gray-900">{comment.user.username}</p>
                      <p className="text-xs text-gray-500">{formatDate(comment.created_at)}</p>
                    </div>
                  </div>
                  <p className="text-gray-700">{comment.content}</p>
                </div>
              ))
            ) : (
              <p className="text-gray-500">No comments yet. Be the first to share your thoughts!</p>
            )}
          </div>
        </section>
      </article>
    </>
  );
};

export default BlogDetail;
