import React from 'react';

interface User {
  id: string;
  username: string;
  full_name?: string;
}

interface CommentProps {
  id: string;
  content: string;
  created_at: string;
  user: User;
}

const Comment: React.FC<CommentProps> = ({ id, content, created_at, user }) => {
  // Format date for display
  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };
  
  // Get display name (full name if available, otherwise username)
  const displayName = user?.full_name || user?.username || 'Anonymous User';
  
  // Get first letter of name for avatar
  const avatarLetter = displayName.charAt(0).toUpperCase();
  
  return (
    <div className="flex space-x-4 py-6 border-b border-gray-200 last:border-b-0">
      <div className="flex-shrink-0">
        <div className="h-10 w-10 rounded-full bg-blue-100 flex items-center justify-center">
          <span className="font-medium text-blue-800">{avatarLetter}</span>
        </div>
      </div>
      
      <div className="flex-grow">
        <div className="flex items-center justify-between mb-1">
          <h4 className="font-medium text-gray-900">{displayName}</h4>
          <span className="text-sm text-gray-500">{formatDate(created_at)}</span>
        </div>
        
        <div className="text-gray-700 whitespace-pre-line">{content}</div>
      </div>
    </div>
  );
};

export default Comment;