import React from 'react';
import { Link } from 'react-router-dom';

interface Category {
  id: string;
  name: string;
}

interface Author {
  id: string;
  username: string;
  full_name?: string;
}

interface Blog {
  id: string;
  title: string;
  slug: string;
  excerpt?: string;
  featured_image?: string;
  view_count: number;
  like_count: number;
  created_at: string;
  published_at?: string;
  author: Author;
  categories: Category[];
}

interface BlogCardProps {
  blog: Blog;
  variant?: 'default' | 'compact' | 'featured';
}

const BlogCard: React.FC<BlogCardProps> = ({ blog, variant = 'default' }) => {
  // Format date for display
  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });
  };
  
  // Get the published date (or created date as fallback)
  const publishDate = blog.published_at ? formatDate(blog.published_at) : formatDate(blog.created_at);
  
  // Get author name (full name if available, otherwise username)
  const authorName = blog.author.full_name || blog.author.username;
  
  // Default placeholder image for blogs without featured images
  const placeholderImage = 'https://via.placeholder.com/800x400?text=Blog+Post';
  
  // Render featured variant
  if (variant === 'featured') {
    return (
      <div className="bg-white rounded-lg shadow-md overflow-hidden h-full flex flex-col">
        <div className="relative h-64">
          <img
            src={blog.featured_image || placeholderImage}
            alt={blog.title}
            className="w-full h-full object-cover"
          />
          <div className="absolute top-0 left-0 bg-blue-600 text-white px-3 py-1 rounded-br-lg">
            Featured
          </div>
        </div>
        
        <div className="p-6 flex-grow flex flex-col">
          <div className="flex-grow">
            <h3 className="text-2xl font-bold mb-3 line-clamp-2 hover:text-blue-600 transition">
              <Link to={`/blogs/${blog.slug}`}>{blog.title}</Link>
            </h3>
            
            {blog.categories && blog.categories.length > 0 && (
              <div className="flex flex-wrap gap-2 mb-3">
                {blog.categories.slice(0, 3).map((category) => (
                  <Link
                    key={category.id}
                    to={`/blogs/categories/${category.id}`}
                    className="text-xs font-medium bg-blue-100 text-blue-800 px-2 py-1 rounded-full hover:bg-blue-200 transition"
                  >
                    {category.name}
                  </Link>
                ))}
              </div>
            )}
            
            <p className="text-gray-600 mb-4 line-clamp-3">
              {blog.excerpt || 'No excerpt available for this blog post.'}
            </p>
          </div>
          
          <div className="flex items-center justify-between mt-4 text-sm text-gray-500">
            <span>{publishDate}</span>
            <div className="flex items-center space-x-4">
              <span className="flex items-center">
                <svg className="h-4 w-4 mr-1" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" />
                </svg>
                {blog.view_count}
              </span>
              <span className="flex items-center">
                <svg className="h-4 w-4 mr-1 text-red-500" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor">
                  <path fillRule="evenodd" d="M3.172 5.172a4 4 0 015.656 0L10 6.343l1.172-1.171a4 4 0 115.656 5.656L10 17.657l-6.828-6.829a4 4 0 010-5.656z" clipRule="evenodd" />
                </svg>
                {blog.like_count}
              </span>
            </div>
          </div>
        </div>
      </div>
    );
  }
  
  // Render compact variant
  if (variant === 'compact') {
    return (
      <div className="flex items-start space-x-4">
        <div className="flex-shrink-0 w-24 h-24 bg-gray-200 rounded-md overflow-hidden">
          <img
            src={blog.featured_image || placeholderImage}
            alt={blog.title}
            className="w-full h-full object-cover"
          />
        </div>
        
        <div className="flex-grow min-w-0">
          <h3 className="text-base font-medium mb-1 truncate hover:text-blue-600 transition">
            <Link to={`/blogs/${blog.slug}`}>{blog.title}</Link>
          </h3>
          
          <p className="text-sm text-gray-500 mb-1">
            By {authorName} • {publishDate}
          </p>
          
          {blog.categories && blog.categories.length > 0 && (
            <div className="flex flex-wrap gap-1">
              {blog.categories.slice(0, 2).map((category) => (
                <Link
                  key={category.id}
                  to={`/blogs/categories/${category.id}`}
                  className="text-xs font-medium bg-blue-100 text-blue-800 px-1.5 py-0.5 rounded hover:bg-blue-200 transition"
                >
                  {category.name}
                </Link>
              ))}
            </div>
          )}
        </div>
      </div>
    );
  }
  
  // Render default variant
  return (
    <div className="bg-white rounded-lg shadow-md overflow-hidden h-full flex flex-col">
      {blog.featured_image && (
        <div className="h-48 overflow-hidden">
          <img
            src={blog.featured_image}
            alt={blog.title}
            className="w-full h-full object-cover hover:scale-105 transition-transform duration-300"
          />
        </div>
      )}
      
      <div className="p-6 flex-grow flex flex-col">
        <div className="flex-grow">
          <h3 className="text-xl font-bold mb-2 line-clamp-2 hover:text-blue-600 transition">
            <Link to={`/blogs/${blog.slug}`}>{blog.title}</Link>
          </h3>
          
          {blog.categories && blog.categories.length > 0 && (
            <div className="flex flex-wrap gap-2 mb-3">
              {blog.categories.slice(0, 2).map((category) => (
                <Link
                  key={category.id}
                  to={`/blogs/categories/${category.id}`}
                  className="text-xs font-medium bg-blue-100 text-blue-800 px-2 py-1 rounded-full hover:bg-blue-200 transition"
                >
                  {category.name}
                </Link>
              ))}
            </div>
          )}
          
          <p className="text-gray-600 mb-4 line-clamp-3">
            {blog.excerpt || 'No excerpt available for this blog post.'}
          </p>
        </div>
        
        <div className="flex items-center justify-between mt-4 text-sm text-gray-500">
          <div className="flex items-center">
            <div className="flex-shrink-0 mr-3">
              <div className="h-8 w-8 rounded-full bg-blue-100 flex items-center justify-center">
                <span className="font-medium text-blue-800">
                  {blog.author.username.charAt(0).toUpperCase()}
                </span>
              </div>
            </div>
            <div>
              <p className="text-sm font-medium text-gray-900">{authorName}</p>
              <p className="text-xs text-gray-500">{publishDate}</p>
            </div>
          </div>
          
          <div className="flex items-center space-x-2">
            <span className="flex items-center text-xs">
              <svg className="h-4 w-4 mr-1 text-red-500" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor">
                <path fillRule="evenodd" d="M3.172 5.172a4 4 0 015.656 0L10 6.343l1.172-1.171a4 4 0 115.656 5.656L10 17.657l-6.828-6.829a4 4 0 010-5.656z" clipRule="evenodd" />
              </svg>
              {blog.like_count}
            </span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default BlogCard;