import React, { useState, useEffect } from 'react';
import { useAppDispatch, useAppSelector } from '../../store/hooks';
import { setFilters, fetchBlogCategories } from '../../store/slices/blogSlice';

interface BlogFiltersProps {
  onApplyFilters: () => void;
}

const BlogFilters: React.FC<BlogFiltersProps> = ({ onApplyFilters }) => {
  const dispatch = useAppDispatch();
  const { categories, filters } = useAppSelector((state) => state.blogs);
  
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('');
  const [sortBy, setSortBy] = useState<string>(filters.sort_by || 'published_at');
  const [sortOrder, setSortOrder] = useState<'asc' | 'desc'>(filters.order || 'desc');
  
  // Fetch categories on component mount
  useEffect(() => {
    dispatch(fetchBlogCategories());
    
    // Initialize local state from redux store
    if (filters.search) setSearchQuery(filters.search);
    if (filters.category_id) setSelectedCategory(filters.category_id);
  }, [dispatch, filters]);
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    dispatch(
      setFilters({
        page: 1, // Reset to first page when filters change
        search: searchQuery || undefined,
        category_id: selectedCategory || undefined,
        sort_by: sortBy,
        order: sortOrder
      })
    );
    
    onApplyFilters();
  };
  
  const handleReset = () => {
    setSearchQuery('');
    setSelectedCategory('');
    setSortBy('published_at');
    setSortOrder('desc');
    
    dispatch(
      setFilters({
        page: 1,
        per_page: 10,
        sort_by: 'published_at',
        order: 'desc'
      })
    );
    
    onApplyFilters();
  };
  
  return (
    <div className="bg-white rounded-lg shadow-md p-6">
      <form onSubmit={handleSubmit}>
        <div className="space-y-4">
          <div>
            <label htmlFor="search" className="block text-sm font-medium text-gray-700 mb-1">
              Search
            </label>
            <input
              type="text"
              id="search"
              placeholder="Search blogs..."
              className="w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>
          
          <div>
            <label htmlFor="category" className="block text-sm font-medium text-gray-700 mb-1">
              Category
            </label>
            <select
              id="category"
              className="w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
              value={selectedCategory}
              onChange={(e) => setSelectedCategory(e.target.value)}
            >
              <option value="">All Categories</option>
              {categories.map((category) => (
                <option key={category.id} value={category.id}>
                  {category.name}
                </option>
              ))}
            </select>
          </div>
          
          <div>
            <label htmlFor="sort" className="block text-sm font-medium text-gray-700 mb-1">
              Sort By
            </label>
            <select
              id="sort"
              className="w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value)}
            >
              <option value="published_at">Publication Date</option>
              <option value="view_count">Most Viewed</option>
              <option value="like_count">Most Liked</option>
              <option value="title">Title</option>
            </select>
          </div>
          
          <div>
            <label htmlFor="order" className="block text-sm font-medium text-gray-700 mb-1">
              Order
            </label>
            <select
              id="order"
              className="w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
              value={sortOrder}
              onChange={(e) => setSortOrder(e.target.value as 'asc' | 'desc')}
            >
              <option value="desc">Descending</option>
              <option value="asc">Ascending</option>
            </select>
          </div>
          
          <div className="flex space-x-4 pt-2">
            <button
              type="submit"
              className="w-full bg-blue-600 text-white py-2 px-4 rounded-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2"
            >
              Apply Filters
            </button>
            
            <button
              type="button"
              onClick={handleReset}
              className="w-full bg-gray-200 text-gray-800 py-2 px-4 rounded-md hover:bg-gray-300 focus:outline-none focus:ring-2 focus:ring-gray-500 focus:ring-offset-2"
            >
              Reset
            </button>
          </div>
        </div>
      </form>
      
      <div className="mt-6 pt-6 border-t border-gray-200">
        <h3 className="font-medium text-gray-900 mb-3">Popular Tags</h3>
        <div className="flex flex-wrap gap-2">
          {categories.slice(0, 10).map((category) => (
            <button
              key={category.id}
              type="button"
              className={`text-xs rounded-full px-3 py-1.5 font-medium ${
                selectedCategory === category.id
                  ? 'bg-blue-600 text-white'
                  : 'bg-gray-100 text-gray-800 hover:bg-gray-200'
              }`}
              onClick={() => {
                setSelectedCategory(category.id);
                dispatch(
                  setFilters({
                    ...filters,
                    page: 1,
                    category_id: category.id
                  })
                );
                onApplyFilters();
              }}
            >
              {category.name}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
};

export default BlogFilters;