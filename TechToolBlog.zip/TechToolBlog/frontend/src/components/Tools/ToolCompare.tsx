import React, { useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAppSelector, useAppDispatch } from '../../store/hooks';
import { getCurrentComparison, compareTools, clearComparisonTools } from '../../store/slices/toolSlice';
import { Helmet } from 'react-helmet-async';

const ToolCompare: React.FC = () => {
  const { comparisonTools, isLoading, error } = useAppSelector(state => state.tools);
  const dispatch = useAppDispatch();
  const navigate = useNavigate();
  
  // Fetch current comparison
  useEffect(() => {
    dispatch(getCurrentComparison());
  }, [dispatch]);
  
  // Handle remove tool from comparison
  const handleRemoveTool = (toolId: string) => {
    const updatedToolIds = comparisonTools
      .filter(tool => tool.id !== toolId)
      .map(tool => tool.id);
    
    if (updatedToolIds.length === 0) {
      // If no tools left, clear comparison
      dispatch(clearComparisonTools());
      navigate('/tools');
    } else {
      // Update comparison with remaining tools
      dispatch(compareTools(updatedToolIds));
    }
  };
  
  // Star rating component
  const StarRating: React.FC<{ rating: number }> = ({ rating }) => {
    return (
      <div className="flex items-center">
        {[1, 2, 3, 4, 5].map((star) => (
          <svg
            key={star}
            className={`h-4 w-4 ${
              star <= Math.round(rating) ? 'text-yellow-400' : 'text-gray-300'
            }`}
            fill="currentColor"
            viewBox="0 0 20 20"
            xmlns="http://www.w3.org/2000/svg"
          >
            <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
          </svg>
        ))}
        <span className="ml-1 text-sm text-gray-600">{rating.toFixed(1)}</span>
      </div>
    );
  };
  
  if (isLoading) {
    return (
      <div className="flex justify-center items-center min-h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-500"></div>
      </div>
    );
  }
  
  if (error) {
    return (
      <div className="py-10 text-center">
        <h2 className="text-2xl font-bold text-red-600 mb-4">
          {error}
        </h2>
        <button 
          onClick={() => dispatch(getCurrentComparison())}
          className="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700"
        >
          Try Again
        </button>
      </div>
    );
  }
  
  if (!comparisonTools || comparisonTools.length === 0) {
    return (
      <div className="text-center py-10">
        <h2 className="text-2xl font-bold mb-4">No Tools Selected for Comparison</h2>
        <p className="text-gray-600 mb-6">Select tools to compare from the tools listing page.</p>
        <Link to="/tools" className="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700">
          Browse Tools
        </Link>
      </div>
    );
  }
  
  // Extract all unique feature keys from tools
  const allFeatures = Array.from(
    new Set(
      comparisonTools.flatMap(tool => 
        tool.features ? Object.keys(tool.features) : []
      )
    )
  );
  
  // Get categories from all tools
  const allCategories = Array.from(
    new Set(
      comparisonTools.flatMap(tool => 
        tool.categories.map(cat => cat.name)
      )
    )
  );
  
  return (
    <>
      <Helmet>
        <title>Compare Tools | ToolBlog</title>
        <meta name="description" content="Compare different B2B tools side by side." />
      </Helmet>
      
      <div>
        <h1 className="text-3xl font-bold mb-6">Tool Comparison</h1>
        
        <div className="bg-white rounded-lg shadow-md overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                {/* First column header (empty for row labels) */}
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider w-40 border-r">
                  Features
                </th>
                
                {/* Tool headers */}
                {comparisonTools.map(tool => (
                  <th key={tool.id} scope="col" className="px-6 py-3 text-center">
                    <div className="flex flex-col items-center space-y-2">
                      {/* Logo/Image */}
                      <div className="h-16 flex items-center justify-center">
                        {tool.logo_url ? (
                          <img
                            src={tool.logo_url}
                            alt={tool.name}
                            className="h-12 w-auto"
                            onError={(e) => {
                              (e.target as HTMLImageElement).src = 'https://via.placeholder.com/120x60?text=No+Logo';
                            }}
                          />
                        ) : (
                          <div className="text-lg font-semibold text-gray-500">{tool.name}</div>
                        )}
                      </div>
                      
                      {/* Tool name */}
                      <Link to={`/tools/${tool.id}`} className="font-medium text-blue-600 hover:text-blue-800">
                        {tool.name}
                      </Link>
                      
                      {/* Action buttons */}
                      <div className="flex space-x-2">
                        <a
                          href={tool.website_url}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="px-2 py-1 text-xs bg-blue-600 text-white rounded hover:bg-blue-700"
                        >
                          Visit
                        </a>
                        <button
                          onClick={() => handleRemoveTool(tool.id)}
                          className="px-2 py-1 text-xs bg-gray-200 text-gray-700 rounded hover:bg-gray-300"
                        >
                          Remove
                        </button>
                      </div>
                    </div>
                  </th>
                ))}
              </tr>
            </thead>
            
            <tbody className="bg-white divide-y divide-gray-200">
              {/* Rating row */}
              <tr className="bg-gray-50">
                <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900 border-r">
                  Rating
                </td>
                {comparisonTools.map(tool => (
                  <td key={tool.id} className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 text-center">
                    <div className="flex justify-center">
                      <StarRating rating={tool.average_rating} />
                    </div>
                  </td>
                ))}
              </tr>
              
              {/* Categories row */}
              <tr>
                <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900 border-r">
                  Categories
                </td>
                {comparisonTools.map(tool => (
                  <td key={tool.id} className="px-6 py-4 text-sm text-gray-500 text-center">
                    <div className="flex flex-wrap justify-center gap-1">
                      {tool.categories.slice(0, 3).map(category => (
                        <span key={category.id} className="inline-block px-2 py-1 text-xs bg-blue-100 text-blue-800 rounded-full">
                          {category.name}
                        </span>
                      ))}
                      {tool.categories.length > 3 && (
                        <span className="inline-block px-2 py-1 text-xs bg-gray-100 text-gray-800 rounded-full">
                          +{tool.categories.length - 3}
                        </span>
                      )}
                    </div>
                  </td>
                ))}
              </tr>
              
              {/* Description row */}
              <tr className="bg-gray-50">
                <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900 border-r">
                  Description
                </td>
                {comparisonTools.map(tool => (
                  <td key={tool.id} className="px-6 py-4 text-sm text-gray-500">
                    <p className="max-w-xs mx-auto">
                      {tool.description.length > 150
                        ? `${tool.description.substring(0, 150)}...`
                        : tool.description}
                    </p>
                  </td>
                ))}
              </tr>
              
              {/* Pricing row */}
              <tr>
                <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900 border-r">
                  Pricing
                </td>
                {comparisonTools.map(tool => (
                  <td key={tool.id} className="px-6 py-4 text-sm text-gray-500 text-center">
                    <p className="max-w-xs mx-auto">
                      {tool.pricing_info || 'Not specified'}
                    </p>
                  </td>
                ))}
              </tr>
              
              {/* Feature rows */}
              {allFeatures.map(feature => (
                <tr key={feature} className="even:bg-gray-50">
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900 border-r">
                    {feature}
                  </td>
                  {comparisonTools.map(tool => (
                    <td key={tool.id} className="px-6 py-4 text-sm text-gray-500 text-center">
                      {tool.features && feature in tool.features ? (
                        <span>{tool.features[feature] as string}</span>
                      ) : (
                        <span className="text-gray-400">Not specified</span>
                      )}
                    </td>
                  ))}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        
        <div className="mt-6 flex justify-between">
          <Link to="/tools" className="px-4 py-2 text-blue-600 hover:text-blue-800">
            &larr; Back to Tools
          </Link>
          <button
            onClick={() => {
              dispatch(clearComparisonTools());
              navigate('/tools');
            }}
            className="px-4 py-2 bg-gray-200 text-gray-700 rounded hover:bg-gray-300"
          >
            Clear Comparison
          </button>
        </div>
      </div>
    </>
  );
};

export default ToolCompare;
