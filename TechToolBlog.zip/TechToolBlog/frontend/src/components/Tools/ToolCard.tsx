import React from 'react';
import { Link } from 'react-router-dom';
import { useAppDispatch, useAppSelector } from '../../store/hooks';
import { addToComparison } from '../../store/slices/toolSlice';

interface Tool {
  id: string;
  name: string;
  description: string;
  website_url: string;
  logo_url?: string;
  average_rating: number;
  categories?: Array<{ id: string; name: string }>;
}

interface ToolCardProps {
  tool: Tool;
}

const ToolCard: React.FC<ToolCardProps> = ({ tool }) => {
  const dispatch = useAppDispatch();
  const { comparisonTools } = useAppSelector((state) => state.tools);
  
  // Check if the tool is already in comparison
  const isInComparison = comparisonTools.some(t => t.id === tool.id);
  
  // Add tool to comparison
  const handleAddToComparison = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (!isInComparison) {
      dispatch(addToComparison(tool));
    }
  };
  
  return (
    <div className="bg-white rounded-lg shadow-md overflow-hidden hover:shadow-lg transition h-full flex flex-col">
      <div className="p-6 flex-grow">
        <div className="flex items-center mb-4">
          {tool.logo_url ? (
            <img src={tool.logo_url} alt={`${tool.name} logo`} className="w-12 h-12 object-contain mr-4" />
          ) : (
            <div className="w-12 h-12 bg-gray-200 rounded-full flex items-center justify-center mr-4">
              <span className="text-gray-500 font-bold text-xl">{tool.name.charAt(0)}</span>
            </div>
          )}
          <h3 className="text-xl font-semibold">{tool.name}</h3>
        </div>
        
        {tool.categories && tool.categories.length > 0 && (
          <div className="flex flex-wrap gap-1 mb-3">
            {tool.categories.slice(0, 3).map((category) => (
              <span
                key={category.id}
                className="inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium bg-blue-100 text-blue-800"
              >
                {category.name}
              </span>
            ))}
            {tool.categories.length > 3 && (
              <span className="inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium bg-gray-100 text-gray-800">
                +{tool.categories.length - 3} more
              </span>
            )}
          </div>
        )}
        
        <p className="text-gray-600 mb-4 line-clamp-3">{tool.description}</p>
      </div>
      
      <div className="px-6 pb-4">
        <div className="flex justify-between items-center">
          <div className="flex items-center">
            <span className="text-yellow-500 mr-1">★</span>
            <span>{tool.average_rating.toFixed(1)}</span>
          </div>
          
          <div className="flex items-center space-x-2">
            <button
              onClick={handleAddToComparison}
              disabled={isInComparison}
              className={`text-sm ${
                isInComparison
                  ? 'text-gray-400 cursor-not-allowed'
                  : 'text-blue-600 hover:text-blue-800'
              }`}
              title={isInComparison ? 'Already in comparison' : 'Add to comparison'}
            >
              <svg
                className="h-5 w-5"
                xmlns="http://www.w3.org/2000/svg"
                viewBox="0 0 20 20"
                fill="currentColor"
              >
                <path d="M5 4a1 1 0 00-2 0v7.268a2 2 0 000 3.464V16a1 1 0 102 0v-1.268a2 2 0 000-3.464V4zM11 4a1 1 0 10-2 0v1.268a2 2 0 000 3.464V16a1 1 0 102 0V8.732a2 2 0 000-3.464V4zM16 3a1 1 0 011 1v7.268a2 2 0 010 3.464V16a1 1 0 11-2 0v-1.268a2 2 0 010-3.464V4a1 1 0 011-1z" />
              </svg>
            </button>
            
            <Link
              to={`/tools/${tool.id}`}
              className="inline-flex items-center px-3 py-1.5 border border-transparent text-xs font-medium rounded-md text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
            >
              View Details
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ToolCard;