import React from 'react';
import ToolRating from './ToolRating';

interface User {
  id: string;
  username: string;
  full_name?: string;
  email?: string;
}

interface Review {
  id: string;
  user_id: string;
  tool_id: string;
  rating: number;
  content: string;
  created_at: string;
  updated_at: string;
  user?: User;
}

interface ToolReviewProps {
  review: Review;
}

const ToolReview: React.FC<ToolReviewProps> = ({ review }) => {
  // Format the date
  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });
  };
  
  // Get reviewer display name (full name if available, otherwise username)
  const reviewerName = review.user?.full_name || review.user?.username || 'Anonymous User';
  
  // Get first letter of name for the avatar
  const avatarInitial = reviewerName.charAt(0).toUpperCase();
  
  return (
    <div className="border-b border-gray-200 pb-6 mb-6 last:border-b-0 last:pb-0 last:mb-0">
      <div className="flex items-start mb-4">
        <div className="flex-shrink-0 mr-4">
          <div className="h-10 w-10 rounded-full bg-blue-100 flex items-center justify-center">
            <span className="text-blue-600 font-bold">{avatarInitial}</span>
          </div>
        </div>
        
        <div className="flex-grow">
          <div className="flex items-center justify-between mb-1">
            <h4 className="text-lg font-medium text-gray-900">{reviewerName}</h4>
            <span className="text-sm text-gray-500">{formatDate(review.created_at)}</span>
          </div>
          
          <div className="mb-2">
            <ToolRating initialRating={review.rating} readonly size="sm" />
          </div>
          
          <p className="text-gray-700 whitespace-pre-line">{review.content}</p>
        </div>
      </div>
    </div>
  );
};

export default ToolReview;