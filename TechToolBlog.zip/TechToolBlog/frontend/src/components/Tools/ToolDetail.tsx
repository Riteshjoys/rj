import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAppSelector, useAppDispatch } from '../../store/hooks';
import { fetchTool, fetchToolReviews, likeTool, unlikeTool, addReview, compareTools, deleteTool } from '../../store/slices/toolSlice';
import { format } from 'date-fns';
import { Helmet } from 'react-helmet-async';

interface ToolDetailProps {
  toolId: string;
}

const ToolDetail: React.FC<ToolDetailProps> = ({ toolId }) => {
  const { currentTool, reviews, isLoading, error } = useAppSelector(state => state.tools);
  const { user, isAuthenticated } = useAppSelector(state => state.auth);
  const dispatch = useAppDispatch();
  const navigate = useNavigate();
  
  const [reviewContent, setReviewContent] = useState('');
  const [reviewRating, setReviewRating] = useState(5);
  const [liked, setLiked] = useState(false);
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);
  const [showReviewForm, setShowReviewForm] = useState(false);
  
  // Fetch tool and reviews
  useEffect(() => {
    dispatch(fetchTool(toolId));
    dispatch(fetchToolReviews({ id: toolId }));
  }, [toolId, dispatch]);
  
  // Format date for display
  const formatDate = (dateString: string) => {
    try {
      return format(new Date(dateString), 'MMM d, yyyy');
    } catch (error) {
      return 'Invalid date';
    }
  };
  
  // Handle like/unlike
  const handleLikeToggle = () => {
    if (!isAuthenticated) {
      navigate('/login');
      return;
    }
    
    if (liked) {
      dispatch(unlikeTool(toolId));
      setLiked(false);
    } else {
      dispatch(likeTool(toolId));
      setLiked(true);
    }
  };
  
  // Handle review submission
  const handleReviewSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!reviewContent.trim()) return;
    
    dispatch(addReview({ 
      id: toolId, 
      rating: reviewRating, 
      content: reviewContent 
    }));
    
    setReviewContent('');
    setReviewRating(5);
    setShowReviewForm(false);
  };
  
  // Handle compare button click
  const handleCompare = () => {
    if (!isAuthenticated) {
      navigate('/login');
      return;
    }
    
    dispatch(compareTools([toolId])).then(() => {
      navigate('/tools/compare');
    });
  };
  
  // Handle tool deletion
  const handleDelete = () => {
    dispatch(deleteTool(toolId)).then(() => {
      navigate('/tools');
    });
  };
  
  // Star rating input component
  const StarRatingInput: React.FC<{ rating: number; onChange: (rating: number) => void }> = ({ rating, onChange }) => {
    return (
      <div className="flex items-center">
        {[1, 2, 3, 4, 5].map((star) => (
          <button
            key={star}
            type="button"
            onClick={() => onChange(star)}
            className="focus:outline-none"
          >
            <svg
              className={`h-6 w-6 ${
                star <= rating ? 'text-yellow-400' : 'text-gray-300'
              } hover:text-yellow-400`}
              fill="currentColor"
              viewBox="0 0 20 20"
              xmlns="http://www.w3.org/2000/svg"
            >
              <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
            </svg>
          </button>
        ))}
        <span className="ml-2 text-gray-700">{rating}/5</span>
      </div>
    );
  };
  
  // Star rating display component
  const StarRating: React.FC<{ rating: number; showText?: boolean }> = ({ rating, showText = true }) => {
    return (
      <div className="flex items-center">
        {[1, 2, 3, 4, 5].map((star) => (
          <svg
            key={star}
            className={`h-5 w-5 ${
              star <= Math.round(rating) ? 'text-yellow-400' : 'text-gray-300'
            }`}
            fill="currentColor"
            viewBox="0 0 20 20"
            xmlns="http://www.w3.org/2000/svg"
          >
            <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
          </svg>
        ))}
        {showText && <span className="ml-2 text-gray-700">{rating.toFixed(1)}/5</span>}
      </div>
    );
  };
  
  if (isLoading && !currentTool) {
    return (
      <div className="flex justify-center items-center min-h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-500"></div>
      </div>
    );
  }
  
  if (error || !currentTool) {
    return (
      <div className="py-10 text-center">
        <h2 className="text-2xl font-bold text-red-600 mb-4">
          {error || "Failed to load the tool"}
        </h2>
        <button 
          onClick={() => dispatch(fetchTool(toolId))}
          className="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700"
        >
          Try Again
        </button>
      </div>
    );
  }
  
  return (
    <>
      <Helmet>
        <title>{currentTool.name} | ToolBlog</title>
        <meta name="description" content={currentTool.description.substring(0, 160)} />
      </Helmet>
      
      <div className="max-w-4xl mx-auto">
        {/* Tool Header */}
        <header className="bg-white p-6 rounded-lg shadow-md mb-6">
          <div className="flex flex-col md:flex-row items-center md:justify-between mb-6">
            <div className="flex-shrink-0 mb-4 md:mb-0">
              {currentTool.logo_url ? (
                <img
                  src={currentTool.logo_url}
                  alt={currentTool.name}
                  className="h-20 w-auto"
                  onError={(e) => {
                    (e.target as HTMLImageElement).src = 'https://via.placeholder.com/200x80?text=No+Logo';
                  }}
                />
              ) : (
                <div className="h-20 w-40 flex items-center justify-center bg-gray-100 rounded">
                  <span className="text-xl font-semibold text-gray-500">{currentTool.name}</span>
                </div>
              )}
            </div>
            
            <div className="flex flex-col items-center md:items-end">
              <div className="flex items-center mb-2">
                <StarRating rating={currentTool.average_rating} />
                <span className="ml-2 text-sm text-gray-600">
                  ({reviews.length} {reviews.length === 1 ? 'review' : 'reviews'})
                </span>
              </div>
              <div className="flex space-x-3">
                <a
                  href={currentTool.website_url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700"
                >
                  Visit Website
                </a>
                <button
                  onClick={handleCompare}
                  className="px-4 py-2 border border-gray-300 rounded hover:bg-gray-50"
                >
                  Compare
                </button>
                <button
                  onClick={handleLikeToggle}
                  className={`p-2 rounded-full border ${
                    liked ? 'bg-blue-100 border-blue-300 text-blue-600' : 'border-gray-300 hover:bg-gray-50'
                  }`}
                  disabled={!isAuthenticated}
                  title={!isAuthenticated ? 'Login to like this tool' : undefined}
                >
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                    <path d="M2 10.5a1.5 1.5 0 113 0v6a1.5 1.5 0 01-3 0v-6zM6 10.333v5.43a2 2 0 001.106 1.79l.05.025A4 4 0 008.943 18h5.416a2 2 0 001.962-1.608l1.2-6A2 2 0 0015.56 8H12V4a2 2 0 00-2-2 1 1 0 00-1 1v.667a4 4 0 01-.8 2.4L6.8 7.933a4 4 0 00-.8 2.4z" />
                  </svg>
                </button>
              </div>
            </div>
          </div>
          
          <h1 className="text-3xl font-bold text-gray-900 mb-4">{currentTool.name}</h1>
          
          {/* Categories */}
          {currentTool.categories.length > 0 && (
            <div className="flex flex-wrap gap-2 mb-4">
              {currentTool.categories.map(category => (
                <Link 
                  key={category.id}
                  to={`/tools?category=${category.id}`}
                  className="text-sm font-medium bg-blue-100 text-blue-800 px-3 py-1 rounded-full hover:bg-blue-200"
                >
                  {category.name}
                </Link>
              ))}
            </div>
          )}
          
          <p className="text-gray-700 mb-4">{currentTool.description}</p>
          
          {/* Pricing info */}
          {currentTool.pricing_info && (
            <div className="mb-4">
              <h3 className="text-lg font-semibold mb-2">Pricing</h3>
              <p className="text-gray-700">{currentTool.pricing_info}</p>
            </div>
          )}
          
          {/* Features */}
          {currentTool.features && Object.keys(currentTool.features).length > 0 && (
            <div>
              <h3 className="text-lg font-semibold mb-2">Features</h3>
              <ul className="list-disc list-inside text-gray-700">
                {Object.entries(currentTool.features).map(([key, value]) => (
                  <li key={key}>
                    <span className="font-medium">{key}:</span> {value as string}
                  </li>
                ))}
              </ul>
            </div>
          )}
        </header>
        
        {/* Admin Actions */}
        {isAuthenticated && user && (user.role === 'admin' || user.role === 'super_user') && (
          <div className="bg-white p-6 rounded-lg shadow-md mb-6">
            <h2 className="text-lg font-semibold mb-4">Admin Actions</h2>
            <div className="flex space-x-4">
              <Link 
                to={`/admin/tools/edit/${currentTool.id}`}
                className="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700"
              >
                Edit Tool
              </Link>
              <button 
                onClick={() => setShowDeleteConfirm(true)}
                className="px-4 py-2 bg-red-600 text-white rounded hover:bg-red-700"
              >
                Delete Tool
              </button>
            </div>
            
            {/* Delete Confirmation Modal */}
            {showDeleteConfirm && (
              <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
                <div className="bg-white p-6 rounded-lg max-w-md mx-4">
                  <h3 className="text-xl font-bold mb-4">Confirm Deletion</h3>
                  <p className="mb-6">Are you sure you want to delete this tool? This action cannot be undone.</p>
                  <div className="flex justify-end space-x-4">
                    <button 
                      onClick={() => setShowDeleteConfirm(false)}
                      className="px-4 py-2 bg-gray-200 text-gray-800 rounded hover:bg-gray-300"
                    >
                      Cancel
                    </button>
                    <button 
                      onClick={handleDelete}
                      className="px-4 py-2 bg-red-600 text-white rounded hover:bg-red-700"
                    >
                      Delete
                    </button>
                  </div>
                </div>
              </div>
            )}
          </div>
        )}
        
        {/* Reviews Section */}
        <section className="bg-white p-6 rounded-lg shadow-md mb-6">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-2xl font-bold">Reviews ({reviews.length})</h2>
            {isAuthenticated && !showReviewForm && (
              <button
                onClick={() => setShowReviewForm(true)}
                className="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700"
              >
                Write a Review
              </button>
            )}
          </div>
          
          {/* Review Form */}
          {isAuthenticated && showReviewForm && (
            <form onSubmit={handleReviewSubmit} className="mb-8 bg-gray-50 p-4 rounded-md">
              <h3 className="text-lg font-semibold mb-4">Your Review</h3>
              
              <div className="mb-4">
                <label className="block text-gray-700 mb-2">Rating</label>
                <StarRatingInput rating={reviewRating} onChange={setReviewRating} />
              </div>
              
              <div className="mb-4">
                <label htmlFor="review" className="block text-gray-700 mb-2">
                  Review
                </label>
                <textarea
                  id="review"
                  rows={4}
                  className="w-full p-3 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                  value={reviewContent}
                  onChange={(e) => setReviewContent(e.target.value)}
                  placeholder="Share your experience with this tool..."
                  required
                ></textarea>
              </div>
              
              <div className="flex justify-end space-x-3">
                <button
                  type="button"
                  onClick={() => setShowReviewForm(false)}
                  className="px-4 py-2 border border-gray-300 rounded hover:bg-gray-50"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-opacity-50"
                  disabled={isLoading || !reviewContent.trim()}
                >
                  Submit Review
                </button>
              </div>
            </form>
          )}
          
          {!isAuthenticated && (
            <div className="bg-gray-50 p-4 rounded-md mb-6">
              <p className="text-gray-700">
                <Link to="/login" className="text-blue-600 hover:underline">Log in</Link> to write a review.
              </p>
            </div>
          )}
          
          {/* Reviews List */}
          <div className="space-y-6">
            {reviews.length > 0 ? (
              reviews.map(review => (
                <div key={review.id} className="border-b border-gray-200 pb-6">
                  <div className="flex justify-between mb-2">
                    <div className="flex items-center">
                      <img
                        className="h-10 w-10 rounded-full mr-3"
                        src={`https://ui-avatars.com/api/?name=${encodeURIComponent(review.user.username)}&background=random`}
                        alt={review.user.username}
                      />
                      <div>
                        <p className="font-medium text-gray-900">{review.user.username}</p>
                        <p className="text-xs text-gray-500">{formatDate(review.created_at)}</p>
                      </div>
                    </div>
                    <StarRating rating={review.rating} showText={false} />
                  </div>
                  <p className="text-gray-700">{review.content}</p>
                </div>
              ))
            ) : (
              <p className="text-gray-500">No reviews yet. Be the first to share your experience!</p>
            )}
          </div>
        </section>
      </div>
    </>
  );
};

export default ToolDetail;
