import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAppDispatch, useAppSelector } from '../../store/hooks';
import { verifyTwoFactor, requestVerificationCode, resetTwoFactorState, clearError } from '../../store/slices/authSlice';
import { Helmet } from 'react-helmet-async';

const TwoFactorAuth: React.FC = () => {
  const [verificationCode, setVerificationCode] = useState('');
  const [validationError, setValidationError] = useState('');
  const [resendDisabled, setResendDisabled] = useState(false);
  const [countdown, setCountdown] = useState(0);
  
  const { isAuthenticated, isLoading, error, twoFactorEmail } = useAppSelector(state => state.auth);
  const dispatch = useAppDispatch();
  const navigate = useNavigate();
  
  // Redirect to home if already authenticated
  useEffect(() => {
    if (isAuthenticated) {
      navigate('/');
    }
    
    // Redirect to login if two-factor auth is not required
    if (!twoFactorEmail) {
      navigate('/login');
    }
    
    // Clear errors when unmounting
    return () => {
      dispatch(clearError());
      dispatch(resetTwoFactorState());
    };
  }, [isAuthenticated, twoFactorEmail, navigate, dispatch]);
  
  // Handle countdown for resend button
  useEffect(() => {
    if (countdown > 0) {
      const timer = setTimeout(() => setCountdown(countdown - 1), 1000);
      return () => clearTimeout(timer);
    } else if (countdown === 0 && resendDisabled) {
      setResendDisabled(false);
    }
  }, [countdown, resendDisabled]);
  
  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { value } = e.target;
    // Only allow numbers
    if (/^\d*$/.test(value) && value.length <= 6) {
      setVerificationCode(value);
      setValidationError('');
    }
  };
  
  const validateCode = () => {
    if (!verificationCode.trim()) {
      setValidationError('Verification code is required');
      return false;
    }
    
    if (verificationCode.length !== 6) {
      setValidationError('Verification code must be 6 digits');
      return false;
    }
    
    setValidationError('');
    return true;
  };
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!validateCode()) {
      return;
    }
    
    if (twoFactorEmail) {
      dispatch(verifyTwoFactor({
        email: twoFactorEmail,
        verification_code: verificationCode
      }));
    }
  };
  
  const handleResendCode = () => {
    if (twoFactorEmail && !resendDisabled) {
      dispatch(requestVerificationCode(twoFactorEmail));
      setResendDisabled(true);
      setCountdown(60); // 60 second cooldown
    }
  };
  
  return (
    <>
      <Helmet>
        <title>Verify Your Account | ToolBlog</title>
        <meta name="description" content="Verify your account with the verification code sent to your email." />
      </Helmet>
      
      <div className="max-w-md mx-auto mt-10 bg-white p-8 rounded-lg shadow-md">
        <h1 className="text-3xl font-bold text-center mb-6">Verify Your Account</h1>
        
        <div className="mb-6 text-center">
          <p className="text-gray-700">
            We've sent a verification code to your email{' '}
            <span className="font-medium">{twoFactorEmail}</span>.
            Please enter the code below to continue.
          </p>
        </div>
        
        {error && (
          <div className="bg-red-50 text-red-600 p-4 rounded-md mb-6">
            {error}
          </div>
        )}
        
        <form onSubmit={handleSubmit}>
          <div className="mb-6">
            <label htmlFor="verification_code" className="block text-gray-700 mb-2">
              Verification Code
            </label>
            <input
              type="text"
              id="verification_code"
              className={`w-full p-3 border rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 text-center text-2xl tracking-widest ${
                validationError ? 'border-red-500' : 'border-gray-300'
              }`}
              value={verificationCode}
              onChange={handleChange}
              placeholder="• • • • • •"
              maxLength={6}
              disabled={isLoading}
            />
            {validationError && (
              <p className="text-red-500 text-sm mt-1">{validationError}</p>
            )}
          </div>
          
          <button
            type="submit"
            className="w-full bg-blue-600 text-white py-3 rounded-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-opacity-50 transition-colors"
            disabled={isLoading}
          >
            {isLoading ? (
              <span className="flex items-center justify-center">
                <svg className="animate-spin -ml-1 mr-2 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                  <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                  <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                </svg>
                Verifying...
              </span>
            ) : (
              'Verify'
            )}
          </button>
        </form>
        
        <div className="mt-6 text-center">
          <p className="text-gray-700">
            Didn't receive the code?{' '}
            <button
              onClick={handleResendCode}
              className={`text-blue-600 hover:underline focus:outline-none ${resendDisabled ? 'opacity-50 cursor-not-allowed' : ''}`}
              disabled={resendDisabled || isLoading}
            >
              Resend Code {countdown > 0 && `(${countdown}s)`}
            </button>
          </p>
        </div>
      </div>
    </>
  );
};

export default TwoFactorAuth;
