import React, { useState, useRef } from 'react';
import { useAppDispatch } from '../../store/hooks';
import { uploadToolsCSV } from '../../store/slices/toolSlice';

interface CSVUploadResult {
  total_imported: number;
  failed_entries: Array<{
    row: number;
    reason: string;
    data?: Record<string, any>;
  }>;
  message: string;
}

const ToolUpload: React.FC = () => {
  const dispatch = useAppDispatch();
  const fileInputRef = useRef<HTMLInputElement>(null);
  
  const [isUploading, setIsUploading] = useState(false);
  const [file, setFile] = useState<File | null>(null);
  const [result, setResult] = useState<CSVUploadResult | null>(null);
  const [error, setError] = useState<string | null>(null);
  
  // Handle file selection
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFile = e.target.files?.[0];
    
    if (selectedFile) {
      // Validate file type
      if (!selectedFile.name.endsWith('.csv')) {
        setError('Please select a CSV file');
        setFile(null);
        return;
      }
      
      setFile(selectedFile);
      setError(null);
      setResult(null);
    }
  };
  
  // Reset the form
  const handleReset = () => {
    setFile(null);
    setResult(null);
    setError(null);
    
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };
  
  // Handle file upload
  const handleUpload = async () => {
    if (!file) {
      setError('Please select a file first');
      return;
    }
    
    setIsUploading(true);
    setError(null);
    setResult(null);
    
    try {
      const formData = new FormData();
      formData.append('file', file);
      
      // Add metadata about the file for potential server-side validation
      formData.append('filename', file.name);
      formData.append('filesize', file.size.toString());
      formData.append('filetype', file.type);
      
      const uploadResult = await dispatch(uploadToolsCSV(formData)).unwrap();
      setResult(uploadResult);
      
      // Clear the file input on successful upload
      if (uploadResult.total_imported > 0 && !uploadResult.failed_entries.length) {
        handleReset();
      }
    } catch (err: any) {
      // Enhanced error handling
      if (typeof err === 'string') {
        setError(err);
      } else if (err instanceof Error) {
        setError(err.message);
      } else if (err.message) {
        setError(err.message);
      } else {
        setError('Failed to upload tools. Please try again.');
      }
      console.error('Tool upload failed:', err);
    } finally {
      setIsUploading(false);
    }
  };
  
  // Download sample CSV template
  const handleDownloadTemplate = () => {
    const csvContent = 'name,description,website_url,pricing_info,logo_url,categories\n' +
      'Example Tool,A powerful tool for businesses,https://example.com,Free/Premium,https://example.com/logo.png,"B2B, Marketing, Analytics"\n' +
      'Another Tool,An AI-powered analytics tool,https://anothertool.com,Subscription,"","Analytics, AI"';
    
    const blob = new Blob([csvContent], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'tool_template.csv';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };
  
  return (
    <div className="bg-white rounded-lg shadow-md p-6">
      <h2 className="text-lg font-bold mb-4">Bulk Upload Tools</h2>
      
      <div className="mb-6">
        <p className="text-gray-600 mb-2">
          Upload a CSV file containing tool data. Make sure the file follows the required format.
        </p>
        <button
          type="button"
          onClick={handleDownloadTemplate}
          className="text-blue-600 hover:text-blue-800 text-sm font-medium focus:outline-none"
        >
          Download template CSV
        </button>
      </div>
      
      {error && (
        <div className="bg-red-50 border-l-4 border-red-500 p-4 mb-4">
          <div className="flex">
            <div className="flex-shrink-0">
              <svg
                className="h-5 w-5 text-red-500"
                xmlns="http://www.w3.org/2000/svg"
                viewBox="0 0 20 20"
                fill="currentColor"
              >
                <path
                  fillRule="evenodd"
                  d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z"
                  clipRule="evenodd"
                />
              </svg>
            </div>
            <div className="ml-3">
              <p className="text-sm text-red-700">{error}</p>
            </div>
          </div>
        </div>
      )}
      
      {result && (
        <div className={`mb-4 p-4 rounded-md ${
          result.failed_entries.length > 0 
            ? 'bg-yellow-50 border border-yellow-300' 
            : 'bg-green-50 border border-green-300'
        }`}>
          <h3 className="text-base font-medium mb-2">
            {result.failed_entries.length > 0 
              ? 'Upload Partially Successful' 
              : 'Upload Successful'}
          </h3>
          <p className="text-sm">
            Successfully imported {result.total_imported} tool{result.total_imported !== 1 ? 's' : ''}.
          </p>
          
          {result.failed_entries.length > 0 && (
            <div className="mt-3">
              <p className="text-sm font-medium mb-2">
                Failed to import {result.failed_entries.length} entries:
              </p>
              <ul className="list-disc pl-5 text-sm text-gray-600 space-y-1">
                {result.failed_entries.map((entry, index) => (
                  <li key={index}>
                    Row {entry.row}: {entry.reason}
                  </li>
                ))}
              </ul>
            </div>
          )}
        </div>
      )}
      
      <div className="mb-6">
        <label className="block text-sm font-medium text-gray-700 mb-2">
          CSV File
        </label>
        <div className="flex items-center">
          <input
            type="file"
            accept=".csv"
            ref={fileInputRef}
            onChange={handleFileChange}
            className="sr-only"
            id="csv-upload"
          />
          <label
            htmlFor="csv-upload"
            className="cursor-pointer py-2 px-3 border border-gray-300 rounded-md text-sm leading-4 font-medium text-gray-700 hover:bg-gray-50"
          >
            Choose File
          </label>
          <span className="ml-3 text-sm text-gray-500">
            {file ? file.name : 'No file selected'}
          </span>
        </div>
        
        <div className="text-xs text-gray-500 mt-1">
          <p>Required columns: name, description, website_url</p>
          <p>Optional columns: pricing_info, logo_url, categories (comma-separated)</p>
        </div>
      </div>
      
      <div className="flex space-x-4">
        <button
          type="button"
          onClick={handleUpload}
          disabled={!file || isUploading}
          className="inline-flex items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 disabled:opacity-50"
        >
          {isUploading ? (
            <>
              <svg
                className="animate-spin -ml-1 mr-2 h-4 w-4 text-white"
                xmlns="http://www.w3.org/2000/svg"
                fill="none"
                viewBox="0 0 24 24"
              >
                <circle
                  className="opacity-25"
                  cx="12"
                  cy="12"
                  r="10"
                  stroke="currentColor"
                  strokeWidth="4"
                ></circle>
                <path
                  className="opacity-75"
                  fill="currentColor"
                  d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"
                ></path>
              </svg>
              Uploading...
            </>
          ) : (
            'Upload Tools'
          )}
        </button>
        
        <button
          type="button"
          onClick={handleReset}
          className="px-4 py-2 border border-gray-300 rounded-md text-sm font-medium text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
        >
          Reset
        </button>
      </div>
    </div>
  );
};

export default ToolUpload;