import React from 'react';
import { Navigate } from 'react-router-dom';
import { useAppSelector } from '../../store/hooks';

interface AdminRouteProps {
  children: React.ReactNode;
  redirectTo?: string;
}

const AdminRoute: React.FC<AdminRouteProps> = ({ 
  children, 
  redirectTo = '/'
}) => {
  const { user, isAuthenticated, isLoading } = useAppSelector(state => state.auth);
  
  // If authentication is still being checked, show a loading state
  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-500"></div>
      </div>
    );
  }
  
  // If not authenticated or not an admin, redirect
  if (!isAuthenticated || !user || (user.role !== 'admin' && user.role !== 'super_user')) {
    return <Navigate to={redirectTo} />;
  }
  
  // If authenticated and is admin, render the children
  return <>{children}</>;
};

export default AdminRoute;