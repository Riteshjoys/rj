import axios, { AxiosRequestConfig } from 'axios';

// Create axios instance
export const api = axios.create({
  baseURL: import.meta.env.VITE_API_URL || 'http://localhost:5000',
  headers: {
    'Content-Type': 'application/json',
  },
  withCredentials: true, // Important for cookies/sessions auth
});

// Request interceptor to attach token
api.interceptors.request.use(
  (config: AxiosRequestConfig) => {
    const token = localStorage.getItem('token');
    
    if (token && config.headers) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    
    return config;
  },
  (error) => {
    return Promise.reject(error);
  }
);

// Response interceptor to handle common errors
api.interceptors.response.use(
  (response) => {
    return response;
  },
  async (error) => {
    const originalRequest = error.config;
    
    // Handle 401 Unauthorized errors (token expired)
    if (error.response?.status === 401 && !originalRequest._retry) {
      originalRequest._retry = true;
      
      // Clear token from localStorage
      localStorage.removeItem('token');
      
      // Only redirect to login if we're not already on an authentication page
      const authPages = ['/login', '/register', '/auth', '/forgot-password', '/reset-password'];
      const currentPath = window.location.pathname;
      
      if (!authPages.some(page => currentPath.startsWith(page))) {
        // Store the current path for post-login redirect
        sessionStorage.setItem('redirectAfterLogin', currentPath);
        window.location.href = '/login';
      }
    }
    
    // Handle 403 Forbidden errors (insufficient permissions)
    if (error.response?.status === 403) {
      console.error('Permission denied:', error.response.data?.detail || 'You do not have permission to perform this action');
      // We can dispatch an event or notification here if needed
    }
    
    // Handle 404 Not Found
    if (error.response?.status === 404) {
      console.error('Resource not found:', error.response.data?.detail || 'The requested resource was not found');
    }
    
    // Handle 500 Server Error
    if (error.response?.status >= 500) {
      console.error('Server error:', error.response.data?.detail || 'An unexpected server error occurred');
    }
    
    // Enhance error object with better formatting
    if (error.response?.data) {
      if (typeof error.response.data === 'object' && error.response.data.detail) {
        error.message = error.response.data.detail;
      } else if (typeof error.response.data === 'string') {
        error.message = error.response.data;
      }
    }
    
    return Promise.reject(error);
  }
);

// Export API functions for different resources

// Auth API
export const authApi = {
  login: (username: string, password: string) => {
    const formData = new FormData();
    formData.append('username', username);
    formData.append('password', password);
    return api.post('/api/login', formData);
  },
  
  register: (userData: any) => {
    return api.post('/api/register', userData);
  },
  
  verifyTwoFactor: (email: string, code: string) => {
    return api.post('/api/two-factor-auth', { email, verification_code: code });
  },
  
  requestVerificationCode: (email: string) => {
    return api.post('/api/request-verification-code', { email });
  },
  
  resetPassword: (email: string) => {
    return api.post('/api/reset-password', { email });
  },
  
  getCurrentUser: () => {
    return api.get('/api/me');
  },
};

// Blog API
export const blogApi = {
  getBlogs: (params: any = {}) => {
    return api.get('/api/blogs', { params });
  },
  
  getUserBlogs: (params: any = {}) => {
    return api.get('/api/blogs/my-blogs', { params });
  },
  
  getBlog: (id: string) => {
    return api.get(`/api/blogs/${id}`);
  },
  
  createBlog: (blogData: any) => {
    return api.post('/api/blogs', blogData);
  },
  
  updateBlog: (id: string, blogData: any) => {
    return api.put(`/api/blogs/${id}`, blogData);
  },
  
  deleteBlog: (id: string) => {
    return api.delete(`/api/blogs/${id}`);
  },
  
  likeBlog: (id: string) => {
    return api.post(`/api/blogs/${id}/like`);
  },
  
  unlikeBlog: (id: string) => {
    return api.delete(`/api/blogs/${id}/like`);
  },
  
  getComments: (id: string, params: any = {}) => {
    return api.get(`/api/blogs/${id}/comments`, { params });
  },
  
  addComment: (id: string, content: string) => {
    return api.post(`/api/blogs/${id}/comment`, { blog_id: id, content });
  },
};

// Tool API
export const toolApi = {
  getTools: (params: any = {}) => {
    return api.get('/api/tools', { params });
  },
  
  getTool: (id: string) => {
    return api.get(`/api/tools/${id}`);
  },
  
  createTool: (toolData: any) => {
    return api.post('/api/tools', toolData);
  },
  
  updateTool: (id: string, toolData: any) => {
    return api.put(`/api/tools/${id}`, toolData);
  },
  
  deleteTool: (id: string) => {
    return api.delete(`/api/tools/${id}`);
  },
  
  likeTool: (id: string) => {
    return api.post(`/api/tools/${id}/like`);
  },
  
  unlikeTool: (id: string) => {
    return api.delete(`/api/tools/${id}/like`);
  },
  
  getReviews: (id: string, params: any = {}) => {
    return api.get(`/api/tools/${id}/reviews`, { params });
  },
  
  addReview: (id: string, rating: number, content: string) => {
    return api.post(`/api/tools/${id}/review`, { tool_id: id, rating, content });
  },
  
  compareTools: (toolIds: string[]) => {
    return api.post('/api/tools/compare', { tool_ids: toolIds });
  },
  
  getCurrentComparison: () => {
    return api.get('/api/tools/compare/current');
  },
  
  searchTools: (query: string) => {
    return api.get(`/api/tools/search?query=${query}`);
  },
  
  getTrendingTools: (limit: number = 10) => {
    return api.get(`/api/tools/trending?limit=${limit}`);
  },
  
  uploadToolsCSV: (file: File) => {
    const formData = new FormData();
    formData.append('file', file);
    
    return api.post('/api/tools/upload-csv', formData, {
      headers: {
        'Content-Type': 'multipart/form-data'
      }
    });
  },
};

// Category API
export const categoryApi = {
  getCategories: (params: any = {}) => {
    return api.get('/api/categories', { params });
  },
  
  getCategoryHierarchy: (params: any = {}) => {
    return api.get('/api/categories/hierarchy', { params });
  },
  
  getCategory: (id: string) => {
    return api.get(`/api/categories/${id}`);
  },
  
  createCategory: (categoryData: any) => {
    return api.post('/api/categories', categoryData);
  },
  
  updateCategory: (id: string, categoryData: any) => {
    return api.put(`/api/categories/${id}`, categoryData);
  },
  
  deleteCategory: (id: string) => {
    return api.delete(`/api/categories/${id}`);
  },
};

// User API
export const userApi = {
  getUsers: (params: any = {}) => {
    return api.get('/api/users', { params });
  },
  
  getUser: (id: string) => {
    return api.get(`/api/users/${id}`);
  },
  
  updateUser: (id: string, userData: any) => {
    return api.put(`/api/users/${id}`, userData);
  },
  
  changePassword: (id: string, oldPassword: string, newPassword: string) => {
    return api.patch(`/api/users/${id}/change-password`, { 
      old_password: oldPassword, 
      new_password: newPassword 
    });
  },
  
  updateUserRole: (id: string, role: string) => {
    return api.patch(`/api/users/${id}/role`, { role });
  },
  
  deleteUser: (id: string) => {
    return api.delete(`/api/users/${id}`);
  },
};
