import React from 'react';
import { Link } from 'react-router-dom';
import { Helmet } from 'react-helmet-async';
import { useAppSelector } from '../store/hooks';
import BlogList from '../components/Blogs/BlogList';

const BlogsPage: React.FC = () => {
  const { isAuthenticated } = useAppSelector((state) => state.auth);

  return (
    <>
      <Helmet>
        <title>Blog | ToolHub</title>
        <meta name="description" content="Read the latest articles, guides, and reviews about B2B tools and strategies" />
      </Helmet>

      <div className="container mx-auto px-4 py-8">
        {/* Header with page title and create button */}
        <div className="flex justify-between items-center mb-8">
          <div>
            <h1 className="text-3xl font-bold mb-2">Blog</h1>
            <p className="text-gray-600">
              Read the latest articles, guides, and reviews about B2B tools and strategies
            </p>
          </div>

          {isAuthenticated && (
            <Link
              to="/blogs/new"
              className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
            >
              <svg className="h-5 w-5 mr-2" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6v6m0 0v6m0-6h6m-6 0H6" />
              </svg>
              Create Blog Post
            </Link>
          )}
        </div>

        {/* Main Content */}
        <BlogList showFeatured={true} />
      </div>
    </>
  );
};

export default BlogsPage;