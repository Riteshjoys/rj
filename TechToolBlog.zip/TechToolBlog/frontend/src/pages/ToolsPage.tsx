import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { Helmet } from 'react-helmet-async';
import { useAppDispatch, useAppSelector } from '../store/hooks';
import { fetchTools, setFilters, fetchToolCategories } from '../store/slices/toolSlice';

const ToolsPage: React.FC = () => {
  const dispatch = useAppDispatch();
  const { tools, categories, isLoading, hasMore, filters } = useAppSelector((state) => state.tools);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('');
  const [sortBy, setSortBy] = useState<string>(filters.sort_by || 'average_rating');
  const [sortOrder, setSortOrder] = useState<'asc' | 'desc'>(filters.order || 'desc');
  
  // Fetch tools and categories when component mounts
  useEffect(() => {
    dispatch(fetchTools(filters));
    dispatch(fetchToolCategories());
  }, [dispatch, filters]);
  
  // Update filters when search query, category, or sorting changes
  const applyFilters = () => {
    dispatch(
      setFilters({
        page: 1, // Reset to first page when filters change
        search: searchQuery || undefined,
        category_id: selectedCategory || undefined,
        sort_by: sortBy,
        order: sortOrder
      })
    );
  };
  
  // Handle search form submission
  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    applyFilters();
  };
  
  // Handle infinite scroll / load more
  const loadMore = () => {
    if (!isLoading && hasMore) {
      dispatch(
        setFilters({
          ...filters,
          page: filters.page + 1
        })
      );
    }
  };
  
  return (
    <>
      <Helmet>
        <title>Browse Tools | ToolHub</title>
        <meta name="description" content="Discover and compare the best B2B tools for your business needs" />
      </Helmet>
      
      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold mb-2">Browse Tools</h1>
          <p className="text-gray-600">
            Discover and compare the best B2B tools for your business needs
          </p>
        </div>
        
        {/* Search and Filters */}
        <div className="bg-white rounded-lg shadow-md p-6 mb-8">
          <form onSubmit={handleSearch} className="mb-6">
            <div className="flex flex-col md:flex-row gap-4">
              <div className="flex-grow">
                <label htmlFor="search" className="block text-sm font-medium text-gray-700 mb-1">
                  Search
                </label>
                <input
                  type="text"
                  id="search"
                  placeholder="Search tools..."
                  className="w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                />
              </div>
              
              <div className="w-full md:w-64">
                <label htmlFor="category" className="block text-sm font-medium text-gray-700 mb-1">
                  Category
                </label>
                <select
                  id="category"
                  className="w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                  value={selectedCategory}
                  onChange={(e) => setSelectedCategory(e.target.value)}
                >
                  <option value="">All Categories</option>
                  {categories.map((category) => (
                    <option key={category.id} value={category.id}>
                      {category.name}
                    </option>
                  ))}
                </select>
              </div>
              
              <div className="w-full md:w-48">
                <label htmlFor="sort" className="block text-sm font-medium text-gray-700 mb-1">
                  Sort By
                </label>
                <select
                  id="sort"
                  className="w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                  value={sortBy}
                  onChange={(e) => setSortBy(e.target.value)}
                >
                  <option value="average_rating">Rating</option>
                  <option value="created_at">Newest</option>
                  <option value="name">Name</option>
                </select>
              </div>
              
              <div className="w-full md:w-48">
                <label htmlFor="order" className="block text-sm font-medium text-gray-700 mb-1">
                  Order
                </label>
                <select
                  id="order"
                  className="w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                  value={sortOrder}
                  onChange={(e) => setSortOrder(e.target.value as 'asc' | 'desc')}
                >
                  <option value="desc">Descending</option>
                  <option value="asc">Ascending</option>
                </select>
              </div>
              
              <div className="self-end">
                <button
                  type="submit"
                  className="bg-blue-600 text-white py-2 px-4 rounded-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2"
                >
                  Apply Filters
                </button>
              </div>
            </div>
          </form>
        </div>
        
        {/* Tool List */}
        {isLoading && tools.length === 0 ? (
          <div className="flex justify-center items-center h-64">
            <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-500"></div>
          </div>
        ) : tools.length === 0 ? (
          <div className="bg-white rounded-lg shadow-md p-8 text-center">
            <h3 className="text-xl font-medium text-gray-900 mb-2">No tools found</h3>
            <p className="text-gray-600 mb-4">
              Try adjusting your search or filter criteria
            </p>
            <button
              onClick={() => {
                setSearchQuery('');
                setSelectedCategory('');
                setSortBy('average_rating');
                setSortOrder('desc');
                dispatch(
                  setFilters({
                    page: 1,
                    per_page: 10,
                    sort_by: 'average_rating',
                    order: 'desc'
                  })
                );
              }}
              className="text-blue-600 hover:text-blue-800 font-medium"
            >
              Clear all filters
            </button>
          </div>
        ) : (
          <>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
              {tools.map((tool) => (
                <div key={tool.id} className="bg-white rounded-lg shadow-md overflow-hidden hover:shadow-lg transition">
                  <div className="p-6">
                    <div className="flex items-center mb-4">
                      {tool.logo_url ? (
                        <img src={tool.logo_url} alt={`${tool.name} logo`} className="w-12 h-12 object-contain mr-4" />
                      ) : (
                        <div className="w-12 h-12 bg-gray-200 rounded-full flex items-center justify-center mr-4">
                          <span className="text-gray-500 font-bold text-xl">{tool.name.charAt(0)}</span>
                        </div>
                      )}
                      <h3 className="text-xl font-semibold">{tool.name}</h3>
                    </div>
                    <p className="text-gray-600 mb-4 line-clamp-3">{tool.description}</p>
                    <div className="flex justify-between items-center">
                      <div className="flex items-center">
                        <span className="text-yellow-500 mr-1">★</span>
                        <span>{tool.average_rating.toFixed(1)}</span>
                      </div>
                      <Link to={`/tools/${tool.id}`} className="text-blue-600 hover:underline">
                        View Details
                      </Link>
                    </div>
                  </div>
                </div>
              ))}
            </div>
            
            {/* Load More Button */}
            {hasMore && (
              <div className="flex justify-center">
                <button
                  onClick={loadMore}
                  disabled={isLoading}
                  className="bg-white border border-gray-300 rounded-md py-2 px-4 text-sm font-medium text-gray-700 hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 disabled:opacity-50"
                >
                  {isLoading ? 'Loading...' : 'Load More'}
                </button>
              </div>
            )}
          </>
        )}
      </div>
    </>
  );
};

export default ToolsPage;