import React, { useEffect } from 'react';
import { useAppDispatch, useAppSelector } from '../store/hooks';
import { getTrendingTools } from '../store/slices/toolSlice';
import { Helmet } from 'react-helmet-async';

const HomePage: React.FC = () => {
  const dispatch = useAppDispatch();
  const { tools, isLoading } = useAppSelector((state) => state.tools);
  
  useEffect(() => {
    // Load trending tools when component mounts
    dispatch(getTrendingTools(5));
  }, [dispatch]);
  
  return (
    <>
      <Helmet>
        <title>Home | B2B Tool Listing Platform</title>
        <meta name="description" content="Discover and compare the best B2B tools for your business needs." />
      </Helmet>
      
      <div className="container mx-auto py-8">
        {/* Hero Section */}
        <section className="bg-gradient-to-r from-blue-600 to-purple-600 text-white rounded-lg shadow-xl p-8 mb-12">
          <div className="max-w-3xl">
            <h1 className="text-4xl font-bold mb-4">Find the Perfect B2B Tools for Your Business</h1>
            <p className="text-xl mb-6">Discover, compare, and review the best tools to help your business grow.</p>
            <div className="flex flex-wrap gap-4">
              <a href="/tools" className="px-6 py-3 bg-white text-blue-600 font-semibold rounded-lg shadow-md hover:bg-blue-50 transition">
                Browse Tools
              </a>
              <a href="/blogs" className="px-6 py-3 bg-transparent border-2 border-white text-white font-semibold rounded-lg hover:bg-white hover:text-blue-600 transition">
                Read Our Blog
              </a>
            </div>
          </div>
        </section>
        
        {/* Trending Tools Section */}
        <section className="mb-12">
          <div className="flex justify-between items-center mb-6">
            <h2 className="text-2xl font-bold">Trending Tools</h2>
            <a href="/tools" className="text-blue-600 hover:underline">View All</a>
          </div>
          
          {isLoading ? (
            <div className="flex justify-center py-12">
              <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-500"></div>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {tools.slice(0, 6).map((tool) => (
                <div key={tool.id} className="bg-white rounded-lg shadow-md overflow-hidden hover:shadow-lg transition">
                  <div className="p-6">
                    <div className="flex items-center mb-4">
                      {tool.logo_url ? (
                        <img src={tool.logo_url} alt={`${tool.name} logo`} className="w-12 h-12 object-contain mr-4" />
                      ) : (
                        <div className="w-12 h-12 bg-gray-200 rounded-full flex items-center justify-center mr-4">
                          <span className="text-gray-500 font-bold text-xl">{tool.name.charAt(0)}</span>
                        </div>
                      )}
                      <h3 className="text-xl font-semibold">{tool.name}</h3>
                    </div>
                    <p className="text-gray-600 mb-4 line-clamp-2">{tool.description}</p>
                    <div className="flex justify-between items-center">
                      <div className="flex items-center">
                        <span className="text-yellow-500 mr-1">★</span>
                        <span>{tool.average_rating.toFixed(1)}</span>
                      </div>
                      <a href={`/tools/${tool.id}`} className="text-blue-600 hover:underline">View Details</a>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </section>
        
        {/* Categories Section */}
        <section className="mb-12">
          <h2 className="text-2xl font-bold mb-6">Popular Categories</h2>
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
            {['Marketing', 'Sales', 'Customer Support', 'Analytics', 'Project Management', 'HR & Recruiting', 'Finance', 'Development'].map((category) => (
              <a 
                key={category} 
                href={`/tools?category=${category}`} 
                className="bg-white p-4 rounded-lg shadow text-center hover:shadow-md transition"
              >
                <span className="font-medium">{category}</span>
              </a>
            ))}
          </div>
        </section>
        
        {/* Latest Blog Posts Section */}
        <section>
          <div className="flex justify-between items-center mb-6">
            <h2 className="text-2xl font-bold">Latest From Our Blog</h2>
            <a href="/blogs" className="text-blue-600 hover:underline">View All Posts</a>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {/* This would be populated with real data from the API */}
            {Array.from({ length: 3 }).map((_, index) => (
              <div key={index} className="bg-white rounded-lg shadow-md overflow-hidden hover:shadow-lg transition">
                <div className="h-48 bg-gray-200"></div>
                <div className="p-6">
                  <h3 className="text-xl font-semibold mb-2">Coming Soon: Blog Posts</h3>
                  <p className="text-gray-600 mb-4">Stay tuned for informative articles about the latest B2B tools and trends.</p>
                  <span className="text-gray-500 text-sm">Coming soon</span>
                </div>
              </div>
            ))}
          </div>
        </section>
      </div>
    </>
  );
};

export default HomePage;