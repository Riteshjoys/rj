import React, { useEffect, useState } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import { Helmet } from 'react-helmet-async';
import { useAppDispatch, useAppSelector } from '../store/hooks';
import { fetchBlog, fetchBlogComments, addComment, likeBlog, unlikeBlog } from '../store/slices/blogSlice';
import Comment from '../components/Blogs/Comment';
import CommentForm from '../components/Blogs/CommentForm';
import BlogCard from '../components/Blogs/BlogCard';

const BlogDetailPage: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const dispatch = useAppDispatch();
  
  const { currentBlog, comments, blogs, isLoading, error } = useAppSelector((state) => state.blogs);
  const { user, isAuthenticated } = useAppSelector((state) => state.auth);
  
  const [isSubmittingComment, setIsSubmittingComment] = useState(false);
  const [hasLiked, setHasLiked] = useState(false);
  
  // Fetch blog and comments when component mounts
  useEffect(() => {
    if (id) {
      dispatch(fetchBlog(id));
      dispatch(fetchBlogComments({ id }));
    }
  }, [dispatch, id]);
  
  // Check if the current user has already liked this blog
  // In a real app, this would be determined by the API response
  useEffect(() => {
    // This is a placeholder; in a real app, we'd check if user has liked the blog
    setHasLiked(false);
  }, [currentBlog, user]);
  
  // Handle adding a comment
  const handleAddComment = async (content: string) => {
    if (!id) return;
    
    setIsSubmittingComment(true);
    try {
      await dispatch(addComment({ id, content })).unwrap();
    } catch (error) {
      console.error('Failed to add comment:', error);
    } finally {
      setIsSubmittingComment(false);
    }
  };
  
  // Handle like/unlike
  const handleLikeToggle = () => {
    if (!id || !isAuthenticated) return;
    
    if (hasLiked) {
      dispatch(unlikeBlog(id));
      setHasLiked(false);
    } else {
      dispatch(likeBlog(id));
      setHasLiked(true);
    }
  };
  
  // Format date for display
  const formatDate = (dateString?: string) => {
    if (!dateString) return '';
    
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });
  };
  
  // Get related blogs (in a real app, this would be based on categories or tags)
  const relatedBlogs = blogs
    .filter(blog => blog.id !== currentBlog?.id)
    .slice(0, 3);
  
  // If loading and no current blog
  if (isLoading && !currentBlog) {
    return (
      <div className="container mx-auto px-4 py-16 flex justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-500"></div>
      </div>
    );
  }
  
  // If error
  if (error && !currentBlog) {
    return (
      <div className="container mx-auto px-4 py-16">
        <div className="bg-red-50 border-l-4 border-red-500 p-4">
          <div className="flex">
            <div className="flex-shrink-0">
              <svg
                className="h-5 w-5 text-red-500"
                xmlns="http://www.w3.org/2000/svg"
                viewBox="0 0 20 20"
                fill="currentColor"
                aria-hidden="true"
              >
                <path
                  fillRule="evenodd"
                  d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z"
                  clipRule="evenodd"
                />
              </svg>
            </div>
            <div className="ml-3">
              <p className="text-sm text-red-700">
                {error || 'Failed to load blog post. Please try again.'}
              </p>
              <Link to="/blogs" className="text-sm font-medium text-red-700 hover:text-red-600">
                Go back to blogs
              </Link>
            </div>
          </div>
        </div>
      </div>
    );
  }
  
  if (!currentBlog) {
    return null; // This shouldn't happen, but just in case
  }
  
  return (
    <>
      <Helmet>
        <title>{currentBlog.title} | ToolHub Blog</title>
        <meta name="description" content={currentBlog.excerpt || `Read ${currentBlog.title} on ToolHub Blog`} />
      </Helmet>
      
      <div className="container mx-auto px-4 py-8">
        {/* Breadcrumbs */}
        <div className="mb-6">
          <nav className="flex" aria-label="Breadcrumb">
            <ol className="inline-flex items-center space-x-1 md:space-x-3">
              <li className="inline-flex items-center">
                <Link to="/" className="text-gray-700 hover:text-blue-600">
                  Home
                </Link>
              </li>
              <li>
                <div className="flex items-center">
                  <svg className="w-6 h-6 text-gray-400" fill="currentColor" viewBox="0 0 20 20">
                    <path fillRule="evenodd" d="M7.293 14.707a1 1 0 010-1.414L10.586 10 7.293 6.707a1 1 0 011.414-1.414l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414 0z" clipRule="evenodd"></path>
                  </svg>
                  <Link to="/blogs" className="ml-1 text-gray-700 hover:text-blue-600 md:ml-2">
                    Blog
                  </Link>
                </div>
              </li>
              <li aria-current="page">
                <div className="flex items-center">
                  <svg className="w-6 h-6 text-gray-400" fill="currentColor" viewBox="0 0 20 20">
                    <path fillRule="evenodd" d="M7.293 14.707a1 1 0 010-1.414L10.586 10 7.293 6.707a1 1 0 011.414-1.414l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414 0z" clipRule="evenodd"></path>
                  </svg>
                  <span className="ml-1 text-gray-500 md:ml-2 font-medium truncate">
                    {currentBlog.title}
                  </span>
                </div>
              </li>
            </ol>
          </nav>
        </div>
        
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-2">
            <div className="bg-white rounded-lg shadow-md overflow-hidden">
              {currentBlog.featured_image && (
                <div className="h-80 overflow-hidden">
                  <img
                    src={currentBlog.featured_image}
                    alt={currentBlog.title}
                    className="w-full h-full object-cover"
                  />
                </div>
              )}
              
              <div className="p-6">
                <h1 className="text-3xl font-bold mb-4">{currentBlog.title}</h1>
                
                <div className="flex flex-wrap items-center text-gray-500 text-sm mb-6">
                  <div className="flex items-center mr-6">
                    <div className="h-8 w-8 rounded-full bg-blue-100 flex items-center justify-center mr-2">
                      <span className="font-medium text-blue-800">
                        {currentBlog.author?.username.charAt(0).toUpperCase()}
                      </span>
                    </div>
                    <span>{currentBlog.author?.full_name || currentBlog.author?.username}</span>
                  </div>
                  
                  <span className="mr-6">{formatDate(currentBlog.published_at || currentBlog.created_at)}</span>
                  
                  <div className="flex items-center mr-6">
                    <svg className="h-4 w-4 mr-1" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" />
                    </svg>
                    {currentBlog.view_count}
                  </div>
                  
                  <div className="flex items-center">
                    <button
                      onClick={handleLikeToggle}
                      disabled={!isAuthenticated}
                      className={`flex items-center focus:outline-none ${!isAuthenticated ? 'cursor-not-allowed opacity-50' : ''}`}
                      title={isAuthenticated ? (hasLiked ? 'Unlike' : 'Like') : 'Sign in to like'}
                    >
                      <svg 
                        className={`h-4 w-4 mr-1 ${hasLiked ? 'text-red-500 fill-current' : 'text-gray-500'}`} 
                        xmlns="http://www.w3.org/2000/svg" 
                        viewBox="0 0 20 20" 
                        fill={hasLiked ? 'currentColor' : 'none'}
                        stroke="currentColor"
                      >
                        <path fillRule="evenodd" d="M3.172 5.172a4 4 0 015.656 0L10 6.343l1.172-1.171a4 4 0 115.656 5.656L10 17.657l-6.828-6.829a4 4 0 010-5.656z" clipRule="evenodd" />
                      </svg>
                      {currentBlog.like_count}
                    </button>
                  </div>
                </div>
                
                {currentBlog.categories && currentBlog.categories.length > 0 && (
                  <div className="flex flex-wrap gap-2 mb-6">
                    {currentBlog.categories.map((category) => (
                      <Link
                        key={category.id}
                        to={`/blogs/categories/${category.id}`}
                        className="text-xs font-medium bg-blue-100 text-blue-800 px-2 py-1 rounded-full hover:bg-blue-200 transition"
                      >
                        {category.name}
                      </Link>
                    ))}
                  </div>
                )}
                
                <div className="prose max-w-none blog-content mb-8">
                  {/* In a real app, we would use a markdown or rich text renderer here */}
                  <div dangerouslySetInnerHTML={{ __html: currentBlog.content }} />
                </div>
                
                {/* Author can edit their own blog */}
                {user && user.id === currentBlog.author_id && (
                  <div className="flex justify-end mb-6">
                    <Link
                      to={`/blogs/edit/${currentBlog.id}`}
                      className="inline-flex items-center px-4 py-2 border border-gray-300 shadow-sm text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
                    >
                      <svg className="h-4 w-4 mr-2" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z" />
                      </svg>
                      Edit Post
                    </Link>
                  </div>
                )}
                
                {/* Comments Section */}
                <div className="border-t border-gray-200 pt-8">
                  <h3 className="text-xl font-bold mb-6">Comments</h3>
                  
                  <CommentForm 
                    blogId={currentBlog.id} 
                    onSubmit={handleAddComment}
                    isSubmitting={isSubmittingComment}
                  />
                  
                  {comments && comments.length > 0 ? (
                    <div className="space-y-0">
                      {comments.map((comment) => (
                        <Comment
                          key={comment.id}
                          id={comment.id}
                          content={comment.content}
                          created_at={comment.created_at}
                          user={comment.user}
                        />
                      ))}
                    </div>
                  ) : (
                    <p className="text-gray-500 text-center py-8">
                      No comments yet. Be the first to leave a comment!
                    </p>
                  )}
                </div>
              </div>
            </div>
          </div>
          
          {/* Sidebar */}
          <div className="lg:col-span-1">
            {/* Author Info */}
            <div className="bg-white rounded-lg shadow-md p-6 mb-6">
              <h3 className="text-lg font-bold mb-4">About the Author</h3>
              
              <div className="flex items-center mb-4">
                <div className="h-12 w-12 rounded-full bg-blue-100 flex items-center justify-center mr-4">
                  <span className="font-medium text-blue-800 text-xl">
                    {currentBlog.author?.username.charAt(0).toUpperCase()}
                  </span>
                </div>
                
                <div>
                  <h4 className="font-medium">{currentBlog.author?.full_name || currentBlog.author?.username}</h4>
                  <p className="text-sm text-gray-500">Author</p>
                </div>
              </div>
              
              <p className="text-gray-600 text-sm">
                {/* In a real app, we would have author bio information here */}
                Author of insightful articles about B2B tools and business strategies.
              </p>
            </div>
            
            {/* Related Posts */}
            {relatedBlogs.length > 0 && (
              <div className="bg-white rounded-lg shadow-md p-6">
                <h3 className="text-lg font-bold mb-4">Related Posts</h3>
                
                <div className="space-y-4">
                  {relatedBlogs.map((blog) => (
                    <div key={blog.id} className="border-b border-gray-100 pb-4 last:border-b-0 last:pb-0">
                      <h4 className="font-medium hover:text-blue-600 transition line-clamp-2 mb-1">
                        <Link to={`/blogs/${blog.slug}`}>{blog.title}</Link>
                      </h4>
                      <p className="text-sm text-gray-500">
                        {formatDate(blog.published_at || blog.created_at)}
                      </p>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </>
  );
};

export default BlogDetailPage;