import React, { useEffect } from 'react';
import { Link } from 'react-router-dom';
import { Helmet } from 'react-helmet-async';
import { useAppDispatch, useAppSelector } from '../store/hooks';
import { getCurrentComparison, removeFromComparison, clearComparison } from '../store/slices/toolSlice';

const ToolComparePage: React.FC = () => {
  const dispatch = useAppDispatch();
  const { comparisonTools, isLoading } = useAppSelector((state) => state.tools);
  
  // Fetch current comparison when component mounts
  useEffect(() => {
    dispatch(getCurrentComparison());
  }, [dispatch]);
  
  // Handle removing a tool from comparison
  const handleRemoveTool = (id: string) => {
    dispatch(removeFromComparison(id));
  };
  
  // Handle clearing all tools from comparison
  const handleClearComparison = () => {
    dispatch(clearComparison());
  };
  
  // Collect all possible feature keys from all tools
  const allFeatureKeys = comparisonTools.reduce((keys, tool) => {
    if (tool.features) {
      Object.keys(tool.features).forEach(key => {
        if (!keys.includes(key)) {
          keys.push(key);
        }
      });
    }
    return keys;
  }, [] as string[]);
  
  return (
    <>
      <Helmet>
        <title>Compare Tools | ToolHub</title>
        <meta name="description" content="Compare different B2B tools side by side to find the perfect fit for your business" />
      </Helmet>
      
      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold mb-2">Compare Tools</h1>
          <p className="text-gray-600">
            Compare different B2B tools side by side to find the perfect fit for your business
          </p>
        </div>
        
        {/* Comparison Controls */}
        <div className="bg-white rounded-lg shadow-md p-6 mb-8 flex justify-between items-center">
          <div>
            <span className="text-gray-700 font-medium">
              {comparisonTools.length} {comparisonTools.length === 1 ? 'tool' : 'tools'} selected
            </span>
            <span className="text-gray-500 text-sm ml-2">
              (max 5)
            </span>
          </div>
          
          <div className="space-x-4">
            <Link
              to="/tools"
              className="inline-flex items-center px-4 py-2 border border-blue-600 text-sm font-medium rounded-md bg-white text-blue-600 hover:bg-blue-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
            >
              Add More Tools
            </Link>
            
            <button
              onClick={handleClearComparison}
              disabled={comparisonTools.length === 0}
              className="inline-flex items-center px-4 py-2 border border-gray-300 text-sm font-medium rounded-md bg-white text-gray-700 hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 disabled:opacity-50"
            >
              Clear All
            </button>
          </div>
        </div>
        
        {isLoading ? (
          <div className="flex justify-center items-center h-64">
            <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-500"></div>
          </div>
        ) : comparisonTools.length === 0 ? (
          <div className="bg-white rounded-lg shadow-md p-8 text-center">
            <h3 className="text-xl font-medium text-gray-900 mb-2">No tools to compare</h3>
            <p className="text-gray-600 mb-6">
              Add tools to compare them side by side and find the best option for your needs.
            </p>
            <Link
              to="/tools"
              className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
            >
              Browse Tools
            </Link>
          </div>
        ) : (
          <div className="bg-white rounded-lg shadow-md overflow-hidden mb-8">
            {/* Comparison Table */}
            <div className="overflow-x-auto">
              <table className="min-w-full divide-y divide-gray-200">
                <thead className="bg-gray-50">
                  <tr>
                    {/* First column is for row labels */}
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider w-1/4">
                      Feature
                    </th>
                    
                    {/* Tool columns */}
                    {comparisonTools.map((tool) => (
                      <th key={tool.id} scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        <div className="flex flex-col items-center mb-2">
                          {tool.logo_url ? (
                            <img 
                              src={tool.logo_url} 
                              alt={`${tool.name} logo`} 
                              className="h-10 w-10 object-contain mb-2" 
                            />
                          ) : (
                            <div className="h-10 w-10 bg-blue-100 rounded-full flex items-center justify-center mb-2">
                              <span className="text-blue-600 font-bold">{tool.name.charAt(0)}</span>
                            </div>
                          )}
                          <span>{tool.name}</span>
                        </div>
                        <button
                          onClick={() => handleRemoveTool(tool.id)}
                          className="text-gray-400 hover:text-gray-500 mt-1"
                        >
                          <span className="sr-only">Remove {tool.name}</span>
                          <svg className="h-5 w-5" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor">
                            <path fillRule="evenodd" d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z" clipRule="evenodd" />
                          </svg>
                        </button>
                      </th>
                    ))}
                  </tr>
                </thead>
                
                <tbody className="bg-white divide-y divide-gray-200">
                  {/* Basic Info Rows */}
                  <tr>
                    <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                      Rating
                    </td>
                    {comparisonTools.map((tool) => (
                      <td key={tool.id} className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                        <div className="flex items-center">
                          <div className="flex items-center">
                            {[1, 2, 3, 4, 5].map((star) => (
                              <svg
                                key={star}
                                className={`h-5 w-5 ${
                                  star <= Math.round(tool.average_rating)
                                    ? 'text-yellow-400'
                                    : 'text-gray-300'
                                }`}
                                xmlns="http://www.w3.org/2000/svg"
                                viewBox="0 0 20 20"
                                fill="currentColor"
                              >
                                <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                              </svg>
                            ))}
                          </div>
                          <span className="ml-2">{tool.average_rating.toFixed(1)}</span>
                        </div>
                      </td>
                    ))}
                  </tr>
                  
                  <tr>
                    <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                      Website
                    </td>
                    {comparisonTools.map((tool) => (
                      <td key={tool.id} className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                        <a
                          href={tool.website_url}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="text-blue-600 hover:underline"
                        >
                          Visit Site
                        </a>
                      </td>
                    ))}
                  </tr>
                  
                  <tr>
                    <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                      Categories
                    </td>
                    {comparisonTools.map((tool) => (
                      <td key={tool.id} className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                        {tool.categories && tool.categories.length > 0 ? (
                          <div className="flex flex-wrap gap-1">
                            {tool.categories.map((category) => (
                              <span
                                key={category.id}
                                className="inline-flex items-center px-2 py-0.5 rounded text-xs font-medium bg-blue-100 text-blue-800"
                              >
                                {category.name}
                              </span>
                            ))}
                          </div>
                        ) : (
                          'N/A'
                        )}
                      </td>
                    ))}
                  </tr>
                  
                  <tr>
                    <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                      Pricing
                    </td>
                    {comparisonTools.map((tool) => (
                      <td key={tool.id} className="px-6 py-4 text-sm text-gray-500">
                        {tool.pricing_info || 'N/A'}
                      </td>
                    ))}
                  </tr>
                  
                  {/* Features Rows */}
                  {allFeatureKeys.length > 0 && (
                    <>
                      <tr className="bg-gray-50">
                        <td colSpan={comparisonTools.length + 1} className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Features
                        </td>
                      </tr>
                      
                      {allFeatureKeys.map((featureKey) => (
                        <tr key={featureKey}>
                          <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                            {featureKey}
                          </td>
                          
                          {comparisonTools.map((tool) => {
                            const hasFeature = tool.features && tool.features[featureKey];
                            const featureValue = hasFeature ? tool.features[featureKey] : null;
                            
                            return (
                              <td key={tool.id} className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                {featureValue === true ? (
                                  <svg className="h-5 w-5 text-green-500" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor">
                                    <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
                                  </svg>
                                ) : featureValue === false ? (
                                  <svg className="h-5 w-5 text-red-500" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor">
                                    <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z" clipRule="evenodd" />
                                  </svg>
                                ) : featureValue ? (
                                  String(featureValue)
                                ) : (
                                  'N/A'
                                )}
                              </td>
                            );
                          })}
                        </tr>
                      ))}
                    </>
                  )}
                </tbody>
              </table>
            </div>
          </div>
        )}
        
        {/* CTA */}
        {comparisonTools.length > 0 && (
          <div className="text-center mt-8">
            <Link
              to="/tools"
              className="inline-flex items-center px-6 py-3 border border-transparent text-base font-medium rounded-md shadow-sm text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
            >
              Explore More Tools
            </Link>
          </div>
        )}
      </div>
    </>
  );
};

export default ToolComparePage;