import os
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from typing import List, Optional
import logging

# Setup logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Email settings
EMAIL_HOST = os.getenv("EMAIL_HOST", "smtp.example.com")
EMAIL_PORT = int(os.getenv("EMAIL_PORT", "587"))
EMAIL_HOST_USER = os.getenv("EMAIL_HOST_USER", "user@example.com")
EMAIL_HOST_PASSWORD = os.getenv("EMAIL_HOST_PASSWORD", "password")
EMAIL_USE_TLS = os.getenv("EMAIL_USE_TLS", "True").lower() == "true"
DEFAULT_FROM_EMAIL = os.getenv("DEFAULT_FROM_EMAIL", "noreply@example.com")

class EmailService:
    def __init__(self):
        self.host = EMAIL_HOST
        self.port = EMAIL_PORT
        self.username = EMAIL_HOST_USER
        self.password = EMAIL_HOST_PASSWORD
        self.use_tls = EMAIL_USE_TLS
        self.default_from_email = DEFAULT_FROM_EMAIL

    def _connect_to_server(self):
        """Connect to the SMTP server"""
        try:
            if self.use_tls:
                server = smtplib.SMTP(self.host, self.port)
                server.starttls()
            else:
                server = smtplib.SMTP_SSL(self.host, self.port)
            
            server.login(self.username, self.password)
            return server
        except Exception as e:
            logger.error(f"Error connecting to SMTP server: {e}")
            return None

    def send_email(
        self, 
        subject: str, 
        body: str, 
        to_emails: List[str], 
        from_email: Optional[str] = None, 
        is_html: bool = False
    ) -> bool:
        """
        Send an email message
        
        Args:
            subject: Email subject
            body: Email body content
            to_emails: List of recipient email addresses
            from_email: Sender email address (defaults to settings)
            is_html: Whether the body is HTML content
            
        Returns:
            bool: True if email sent successfully, False otherwise
        """
        if not from_email:
            from_email = self.default_from_email
            
        msg = MIMEMultipart()
        msg['From'] = from_email
        msg['To'] = ", ".join(to_emails)
        msg['Subject'] = subject
        
        # Attach body text based on content type
        if is_html:
            msg.attach(MIMEText(body, 'html'))
        else:
            msg.attach(MIMEText(body, 'plain'))
            
        server = self._connect_to_server()
        if not server:
            return False
            
        try:
            server.send_message(msg)
            server.quit()
            logger.info(f"Email sent successfully to {to_emails}")
            return True
        except Exception as e:
            logger.error(f"Failed to send email: {e}")
            server.quit()
            return False

    def send_verification_email(self, to_email: str, verification_code: str) -> bool:
        """Send an email with a verification code for two-factor authentication"""
        subject = "Your Verification Code"
        body = f"""
        <html>
        <body>
            <h2>Verification Code</h2>
            <p>Your verification code is: <strong>{verification_code}</strong></p>
            <p>This code will expire in 10 minutes.</p>
            <p>If you did not request this code, please ignore this email.</p>
        </body>
        </html>
        """
        return self.send_email(subject, body, [to_email], is_html=True)
        
    def send_password_reset_email(self, to_email: str, reset_link: str) -> bool:
        """Send an email with a password reset link"""
        subject = "Password Reset Request"
        body = f"""
        <html>
        <body>
            <h2>Password Reset</h2>
            <p>You have requested to reset your password. Click the link below to reset it:</p>
            <p><a href="{reset_link}">Reset Password</a></p>
            <p>This link will expire in 24 hours.</p>
            <p>If you did not request a password reset, please ignore this email.</p>
        </body>
        </html>
        """
        return self.send_email(subject, body, [to_email], is_html=True)
        
    def send_welcome_email(self, to_email: str, verification_link: str) -> bool:
        """Send a welcome email with an email verification link"""
        subject = "Welcome to our platform!"
        body = f"""
        <html>
        <body>
            <h2>Welcome!</h2>
            <p>Thank you for registering! Please verify your email address by clicking the link below:</p>
            <p><a href="{verification_link}">Verify Email</a></p>
            <p>This link will expire in 24 hours.</p>
        </body>
        </html>
        """
        return self.send_email(subject, body, [to_email], is_html=True)

# Initialize email service
email_service = EmailService()
