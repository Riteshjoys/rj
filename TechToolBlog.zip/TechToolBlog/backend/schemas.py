from typing import List, Optional, Any, Dict, Union
from pydantic import BaseModel, EmailStr, Field, validator, HttpUrl
from datetime import datetime
import uuid
from models import UserRole, BlogStatus

# Base schemas for common fields
class BaseSchema(BaseModel):
    id: uuid.UUID
    created_at: datetime
    updated_at: datetime

    class Config:
        orm_mode = True

# User schemas
class UserBase(BaseModel):
    email: EmailStr
    username: str
    full_name: Optional[str] = None

class UserCreate(UserBase):
    password: str
    confirm_password: str

    @validator('confirm_password')
    def passwords_match(cls, v, values, **kwargs):
        if 'password' in values and v != values['password']:
            raise ValueError('Passwords do not match')
        return v

class UserUpdate(BaseModel):
    email: Optional[EmailStr] = None
    username: Optional[str] = None
    full_name: Optional[str] = None
    
class UserRole(BaseModel):
    role: UserRole

class UserInDB(UserBase, BaseSchema):
    role: UserRole
    is_active: bool
    is_verified: bool

class User(UserInDB):
    pass

# Token schemas
class Token(BaseModel):
    access_token: str
    token_type: str = "bearer"
    user: User

class TokenData(BaseModel):
    username: Optional[str] = None
    user_id: Optional[uuid.UUID] = None
    role: Optional[str] = None

# Two-factor auth schemas
class TwoFactorAuth(BaseModel):
    email: EmailStr
    verification_code: str

# Category schemas
class CategoryBase(BaseModel):
    name: str
    description: Optional[str] = None
    parent_id: Optional[uuid.UUID] = None
    is_for_tools: bool = True
    is_for_blogs: bool = True

class CategoryCreate(CategoryBase):
    pass

class CategoryUpdate(BaseModel):
    name: Optional[str] = None
    description: Optional[str] = None
    parent_id: Optional[uuid.UUID] = None
    is_for_tools: Optional[bool] = None
    is_for_blogs: Optional[bool] = None

class Category(CategoryBase, BaseSchema):
    pass

class CategoryWithSubcategories(Category):
    subcategories: List['CategoryWithSubcategories'] = []

# Tool schemas
class ToolBase(BaseModel):
    name: str
    description: str
    website_url: HttpUrl
    pricing_info: Optional[str] = None
    logo_url: Optional[HttpUrl] = None
    features: Optional[Dict[str, Any]] = None

class ToolCreate(ToolBase):
    category_ids: List[uuid.UUID]

class ToolUpdate(BaseModel):
    name: Optional[str] = None
    description: Optional[str] = None
    website_url: Optional[HttpUrl] = None
    pricing_info: Optional[str] = None
    logo_url: Optional[HttpUrl] = None
    features: Optional[Dict[str, Any]] = None
    category_ids: Optional[List[uuid.UUID]] = None

class Tool(ToolBase, BaseSchema):
    average_rating: float
    categories: List[Category] = []

class ToolWithReviews(Tool):
    reviews: List['ToolReview'] = []
    likes_count: int

# Tool Review schemas
class ToolReviewBase(BaseModel):
    rating: float = Field(..., ge=0, le=5)
    content: str

class ToolReviewCreate(ToolReviewBase):
    tool_id: uuid.UUID

class ToolReview(ToolReviewBase, BaseSchema):
    user_id: uuid.UUID
    tool_id: uuid.UUID
    user: User

# Blog schemas
class BlogBase(BaseModel):
    title: str
    content: str
    excerpt: Optional[str] = None
    featured_image: Optional[HttpUrl] = None
    content_json: Optional[Dict[str, Any]] = None
    
class BlogCreate(BlogBase):
    status: BlogStatus = BlogStatus.DRAFT
    category_ids: List[uuid.UUID] = []
    slug: Optional[str] = None

class BlogUpdate(BaseModel):
    title: Optional[str] = None
    content: Optional[str] = None
    excerpt: Optional[str] = None
    featured_image: Optional[HttpUrl] = None
    content_json: Optional[Dict[str, Any]] = None
    status: Optional[BlogStatus] = None
    category_ids: Optional[List[uuid.UUID]] = None
    slug: Optional[str] = None

class Blog(BlogBase, BaseSchema):
    slug: str
    status: BlogStatus
    author_id: uuid.UUID
    view_count: int
    like_count: int
    published_at: Optional[datetime] = None
    categories: List[Category] = []
    author: User

# Blog Comment schemas
class BlogCommentBase(BaseModel):
    content: str

class BlogCommentCreate(BlogCommentBase):
    blog_id: uuid.UUID

class BlogComment(BlogCommentBase, BaseSchema):
    blog_id: uuid.UUID
    user_id: uuid.UUID
    user: User

# Tool comparison schema
class ToolComparisonCreate(BaseModel):
    tool_ids: List[uuid.UUID] = Field(..., max_items=5)

class ToolComparison(BaseModel):
    tools: List[Tool]

# CSV import schema
class CSVImportResponse(BaseModel):
    total_imported: int
    failed_entries: List[Dict[str, Any]] = []
    message: str

# Search schemas
class SearchQuery(BaseModel):
    query: str
    entity_type: Optional[str] = None  # "blog", "tool", or null for both
    category_id: Optional[uuid.UUID] = None

class SearchResult(BaseModel):
    blogs: List[Blog] = []
    tools: List[Tool] = []

# Filter schemas
class FilterParams(BaseModel):
    categories: Optional[List[uuid.UUID]] = None
    sort_by: Optional[str] = None  # "rating", "name", "date", "likes", "trending"
    order: Optional[str] = "desc"  # "asc" or "desc"
    page: int = 1
    per_page: int = 20
    search: Optional[str] = None
