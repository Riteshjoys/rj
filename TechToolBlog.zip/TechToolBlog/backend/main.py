import os
from fastapi import FastAPI, Depends, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.openapi.utils import get_openapi
from starlette.responses import RedirectResponse

# Import routers
from routers import users, blogs, tools, categories, auth

# Import database
from database import engine, SessionLocal
import models

# Create database tables
models.Base.metadata.create_all(bind=engine)

# Initialize FastAPI app
app = FastAPI(
    title="BloggingToolsAPI",
    description="API for a blogging and B2B tool listing platform",
    version="1.0.0"
)

# Configure CORS
origins = [
    "http://localhost:5000",
    "http://localhost:3000",
    "http://localhost:8080",
    "http://0.0.0.0:5000",
]

app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Include routers
app.include_router(auth.router, prefix="/api", tags=["Authentication"])
app.include_router(users.router, prefix="/api/users", tags=["Users"])
app.include_router(blogs.router, prefix="/api/blogs", tags=["Blogs"])
app.include_router(tools.router, prefix="/api/tools", tags=["Tools"])
app.include_router(categories.router, prefix="/api/categories", tags=["Categories"])

# Root endpoint
@app.get("/", include_in_schema=False)
async def root():
    return RedirectResponse(url="/docs")

# Customize OpenAPI schema for Swagger UI
def custom_openapi():
    if app.openapi_schema:
        return app.openapi_schema
    openapi_schema = get_openapi(
        title="BloggingToolsAPI",
        version="1.0.0",
        description="API for a blogging and B2B tool listing platform",
        routes=app.routes,
    )
    app.openapi_schema = openapi_schema
    return app.openapi_schema

app.openapi = custom_openapi

if __name__ == "__main__":
    import uvicorn
    # Run the app on port 8000
    uvicorn.run("main:app", host="0.0.0.0", port=8000, reload=True)
