from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from typing import List, Optional

from database import get_db
import models
import schemas
from auth import (
    get_current_active_user,
    get_current_super_user,
)

router = APIRouter()

@router.get("/", response_model=List[schemas.Category])
async def get_categories(
    is_for_tools: Optional[bool] = None,
    is_for_blogs: Optional[bool] = None,
    parent_id: Optional[str] = None,
    db: Session = Depends(get_db)
):
    """
    Get all categories with optional filtering
    """
    query = db.query(models.Category)
    
    # Filter by type
    if is_for_tools is not None:
        query = query.filter(models.Category.is_for_tools == is_for_tools)
    
    if is_for_blogs is not None:
        query = query.filter(models.Category.is_for_blogs == is_for_blogs)
    
    # Filter by parent
    if parent_id:
        query = query.filter(models.Category.parent_id == parent_id)
    elif parent_id == "":  # Empty string means only top-level categories
        query = query.filter(models.Category.parent_id == None)
    
    categories = query.all()
    return categories

@router.get("/hierarchy", response_model=List[schemas.CategoryWithSubcategories])
async def get_category_hierarchy(
    is_for_tools: Optional[bool] = None,
    is_for_blogs: Optional[bool] = None,
    db: Session = Depends(get_db)
):
    """
    Get categories in a hierarchical structure
    """
    # Get top-level categories
    query = db.query(models.Category).filter(models.Category.parent_id == None)
    
    # Filter by type
    if is_for_tools is not None:
        query = query.filter(models.Category.is_for_tools == is_for_tools)
    
    if is_for_blogs is not None:
        query = query.filter(models.Category.is_for_blogs == is_for_blogs)
    
    categories = query.all()
    
    # Recursive function to build hierarchy
    def build_hierarchy(categories_list):
        result = []
        for category in categories_list:
            # Create category with empty subcategories list
            cat_dict = schemas.Category.from_orm(category).dict()
            cat_dict["subcategories"] = build_hierarchy(category.subcategories)
            result.append(schemas.CategoryWithSubcategories(**cat_dict))
        return result
    
    return build_hierarchy(categories)

@router.get("/{category_id}", response_model=schemas.Category)
async def get_category(
    category_id: str,
    db: Session = Depends(get_db)
):
    """
    Get a specific category
    """
    category = db.query(models.Category).filter(models.Category.id == category_id).first()
    if category is None:
        raise HTTPException(status_code=404, detail="Category not found")
    return category

@router.post("/", response_model=schemas.Category)
async def create_category(
    category_data: schemas.CategoryCreate,
    current_user: models.User = Depends(get_current_super_user),
    db: Session = Depends(get_db)
):
    """
    Create a new category (super user only)
    """
    # Check if parent category exists if specified
    if category_data.parent_id:
        parent = db.query(models.Category).filter(models.Category.id == category_data.parent_id).first()
        if parent is None:
            raise HTTPException(status_code=404, detail="Parent category not found")
    
    # Check if category with same name exists
    existing = db.query(models.Category).filter(models.Category.name == category_data.name).first()
    if existing:
        raise HTTPException(status_code=400, detail="Category with this name already exists")
    
    # Create category
    db_category = models.Category(
        name=category_data.name,
        description=category_data.description,
        parent_id=category_data.parent_id,
        is_for_tools=category_data.is_for_tools,
        is_for_blogs=category_data.is_for_blogs
    )
    
    db.add(db_category)
    db.commit()
    db.refresh(db_category)
    
    return db_category

@router.put("/{category_id}", response_model=schemas.Category)
async def update_category(
    category_id: str,
    category_data: schemas.CategoryUpdate,
    current_user: models.User = Depends(get_current_super_user),
    db: Session = Depends(get_db)
):
    """
    Update a category (super user only)
    """
    db_category = db.query(models.Category).filter(models.Category.id == category_id).first()
    if db_category is None:
        raise HTTPException(status_code=404, detail="Category not found")
    
    # Check if parent category exists if specified
    if category_data.parent_id:
        parent = db.query(models.Category).filter(models.Category.id == category_data.parent_id).first()
        if parent is None:
            raise HTTPException(status_code=404, detail="Parent category not found")
        
        # Prevent circular reference
        if str(parent.id) == category_id:
            raise HTTPException(status_code=400, detail="Category cannot be its own parent")
    
    # Check if category with same name exists (if name is being updated)
    if category_data.name and category_data.name != db_category.name:
        existing = db.query(models.Category).filter(models.Category.name == category_data.name).first()
        if existing:
            raise HTTPException(status_code=400, detail="Category with this name already exists")
    
    # Update category data
    update_data = category_data.dict(exclude_unset=True)
    for key, value in update_data.items():
        setattr(db_category, key, value)
    
    db.commit()
    db.refresh(db_category)
    
    return db_category

@router.delete("/{category_id}")
async def delete_category(
    category_id: str,
    current_user: models.User = Depends(get_current_super_user),
    db: Session = Depends(get_db)
):
    """
    Delete a category (super user only)
    """
    db_category = db.query(models.Category).filter(models.Category.id == category_id).first()
    if db_category is None:
        raise HTTPException(status_code=404, detail="Category not found")
    
    # Check if category has subcategories
    has_subcategories = db.query(models.Category).filter(models.Category.parent_id == category_id).first()
    if has_subcategories:
        raise HTTPException(
            status_code=400, 
            detail="Cannot delete category that has subcategories. Delete subcategories first."
        )
    
    db.delete(db_category)
    db.commit()
    
    return {"message": "Category deleted successfully"}
