from fastapi import APIRouter, Depends, HTTPException, status, File, UploadFile, Form, Query
from sqlalchemy.orm import Session
from typing import List, Optional
from datetime import datetime
import uuid
import pandas as pd
import io

from database import get_db
import models
import schemas
from auth import (
    get_current_active_user,
    get_current_super_user,
)
from ai_service import ai_service
from utils import process_csv_for_tools, is_valid_url

router = APIRouter()

@router.get("/", response_model=List[schemas.Tool])
async def get_tools(
    skip: int = 0,
    limit: int = 20,
    category_id: Optional[str] = None,
    sort_by: Optional[str] = "average_rating",
    order: Optional[str] = "desc",
    search: Optional[str] = None,
    db: Session = Depends(get_db)
):
    """
    Get list of tools with filtering and sorting
    """
    # Base query
    query = db.query(models.Tool)
    
    # Filter by category
    if category_id:
        query = query.join(models.tool_category).join(models.Category).filter(
            models.Category.id == category_id
        )
    
    # Search
    if search:
        # If simple search
        query = query.filter(
            (models.Tool.name.ilike(f"%{search}%")) | 
            (models.Tool.description.ilike(f"%{search}%"))
        )
    
    # Sort
    if sort_by == "average_rating":
        sort_col = models.Tool.average_rating
    elif sort_by == "name":
        sort_col = models.Tool.name
    elif sort_by == "created_at":
        sort_col = models.Tool.created_at
    else:
        sort_col = models.Tool.average_rating
    
    # Order
    if order == "asc":
        query = query.order_by(sort_col.asc())
    else:
        query = query.order_by(sort_col.desc())
    
    # Pagination
    tools = query.offset(skip).limit(limit).all()
    return tools

@router.get("/search")
async def search_tools(
    query: str,
    db: Session = Depends(get_db)
):
    """
    AI-powered search for tools
    """
    tools = ai_service.search_tools(db, query)
    return {"results": tools}

@router.get("/trending", response_model=List[schemas.Tool])
async def get_trending_tools(
    limit: int = 10,
    db: Session = Depends(get_db)
):
    """
    Get trending tools
    """
    trending_tools = ai_service.analyze_trending_tools(db, limit)
    return trending_tools

@router.get("/{tool_id}", response_model=schemas.ToolWithReviews)
async def get_tool(
    tool_id: str,
    db: Session = Depends(get_db)
):
    """
    Get a specific tool with its reviews
    """
    tool = db.query(models.Tool).filter(models.Tool.id == tool_id).first()
    if tool is None:
        raise HTTPException(status_code=404, detail="Tool not found")
    
    # Count likes
    likes_count = db.query(models.ToolLike).filter(models.ToolLike.tool_id == tool_id).count()
    
    # Create response
    tool_dict = schemas.Tool.from_orm(tool).dict()
    tool_dict["likes_count"] = likes_count
    tool_dict["reviews"] = tool.reviews
    
    return tool_dict

@router.post("/", response_model=schemas.Tool)
async def create_tool(
    tool_data: schemas.ToolCreate,
    current_user: models.User = Depends(get_current_super_user),
    db: Session = Depends(get_db)
):
    """
    Create a new tool (super user only)
    """
    # Validate URL
    if not is_valid_url(str(tool_data.website_url)):
        raise HTTPException(status_code=400, detail="Invalid website URL")
    
    # Create tool
    db_tool = models.Tool(
        name=tool_data.name,
        description=tool_data.description,
        website_url=str(tool_data.website_url),
        pricing_info=tool_data.pricing_info,
        logo_url=tool_data.logo_url,
        features=tool_data.features
    )
    
    db.add(db_tool)
    db.commit()
    db.refresh(db_tool)
    
    # Add categories
    if tool_data.category_ids:
        for category_id in tool_data.category_ids:
            category = db.query(models.Category).filter(models.Category.id == category_id).first()
            if category and category.is_for_tools:
                db_tool.categories.append(category)
        
        db.commit()
        db.refresh(db_tool)
    
    return db_tool

@router.put("/{tool_id}", response_model=schemas.Tool)
async def update_tool(
    tool_id: str,
    tool_data: schemas.ToolUpdate,
    current_user: models.User = Depends(get_current_super_user),
    db: Session = Depends(get_db)
):
    """
    Update a tool (super user only)
    """
    db_tool = db.query(models.Tool).filter(models.Tool.id == tool_id).first()
    if db_tool is None:
        raise HTTPException(status_code=404, detail="Tool not found")
    
    # Validate URL if provided
    if tool_data.website_url and not is_valid_url(str(tool_data.website_url)):
        raise HTTPException(status_code=400, detail="Invalid website URL")
    
    # Update tool data
    update_data = tool_data.dict(exclude_unset=True)
    for key, value in update_data.items():
        if key != "category_ids":  # Handle categories separately
            setattr(db_tool, key, value)
    
    # Update categories
    if tool_data.category_ids is not None:
        # Clear existing categories
        db_tool.categories = []
        
        # Add new categories
        for category_id in tool_data.category_ids:
            category = db.query(models.Category).filter(models.Category.id == category_id).first()
            if category and category.is_for_tools:
                db_tool.categories.append(category)
    
    db.commit()
    db.refresh(db_tool)
    return db_tool

@router.delete("/{tool_id}")
async def delete_tool(
    tool_id: str,
    current_user: models.User = Depends(get_current_super_user),
    db: Session = Depends(get_db)
):
    """
    Delete a tool (super user only)
    """
    db_tool = db.query(models.Tool).filter(models.Tool.id == tool_id).first()
    if db_tool is None:
        raise HTTPException(status_code=404, detail="Tool not found")
    
    db.delete(db_tool)
    db.commit()
    
    return {"message": "Tool deleted successfully"}

@router.post("/upload-csv", response_model=schemas.CSVImportResponse)
async def upload_tools_csv(
    file: UploadFile = File(...),
    current_user: models.User = Depends(get_current_super_user),
    db: Session = Depends(get_db)
):
    """
    Upload a CSV file to create multiple tools (super user only)
    """
    # Check file extension
    if not file.filename.endswith('.csv'):
        raise HTTPException(status_code=400, detail="File must be a CSV")
    
    # Process CSV
    total_imported, failed_entries, message = process_csv_for_tools(file, db)
    
    if total_imported == 0 and not failed_entries:
        raise HTTPException(status_code=400, detail=message)
    
    # Read CSV
    content = await file.read()
    csv_data = pd.read_csv(io.StringIO(content.decode('utf-8')))
    
    # Required columns
    required_columns = ['name', 'description', 'website_url']
    for col in required_columns:
        if col not in csv_data.columns:
            raise HTTPException(status_code=400, detail=f"Missing required column: {col}")
    
    # Process each row
    imported_count = 0
    failed_entries = []
    
    for _, row in csv_data.iterrows():
        try:
            # Basic validation
            if not row['name'] or not row['description'] or not row['website_url']:
                failed_entries.append({"row": row.to_dict(), "error": "Missing required field"})
                continue
            
            # Validate URL
            if not is_valid_url(str(row['website_url'])):
                failed_entries.append({"row": row.to_dict(), "error": "Invalid website URL"})
                continue
            
            # Create tool
            db_tool = models.Tool(
                name=row['name'],
                description=row['description'],
                website_url=str(row['website_url']),
                pricing_info=row.get('pricing_info', None),
                logo_url=row.get('logo_url', None),
                features={} if 'features' not in row else row['features']
            )
            
            db.add(db_tool)
            db.commit()
            db.refresh(db_tool)
            
            # Handle categories if provided
            if 'categories' in row and row['categories']:
                category_names = [c.strip() for c in str(row['categories']).split(',')]
                for name in category_names:
                    # Find or create category
                    category = db.query(models.Category).filter(models.Category.name == name).first()
                    if not category:
                        category = models.Category(name=name, is_for_tools=True)
                        db.add(category)
                        db.commit()
                        db.refresh(category)
                    
                    # Add to tool
                    db_tool.categories.append(category)
                
                db.commit()
            
            imported_count += 1
        
        except Exception as e:
            failed_entries.append({"row": row.to_dict(), "error": str(e)})
    
    return {
        "total_imported": imported_count,
        "failed_entries": failed_entries,
        "message": f"Successfully imported {imported_count} tools. {len(failed_entries)} entries failed."
    }

@router.post("/{tool_id}/review", response_model=schemas.ToolReview)
async def create_review(
    tool_id: str,
    review_data: schemas.ToolReviewCreate,
    current_user: models.User = Depends(get_current_active_user),
    db: Session = Depends(get_db)
):
    """
    Create a review for a tool
    """
    db_tool = db.query(models.Tool).filter(models.Tool.id == tool_id).first()
    if db_tool is None:
        raise HTTPException(status_code=404, detail="Tool not found")
    
    # Check if user already reviewed this tool
    existing_review = db.query(models.ToolReview).filter(
        models.ToolReview.tool_id == tool_id,
        models.ToolReview.user_id == current_user.id
    ).first()
    
    if existing_review:
        raise HTTPException(status_code=400, detail="You have already reviewed this tool")
    
    # Create review
    db_review = models.ToolReview(
        user_id=current_user.id,
        tool_id=tool_id,
        rating=review_data.rating,
        content=review_data.content
    )
    
    db.add(db_review)
    
    # Update tool average rating
    reviews = db.query(models.ToolReview).filter(models.ToolReview.tool_id == tool_id).all()
    total_rating = sum(review.rating for review in reviews) + review_data.rating
    db_tool.average_rating = total_rating / (len(reviews) + 1)
    
    db.commit()
    db.refresh(db_review)
    
    return db_review

@router.get("/{tool_id}/reviews", response_model=List[schemas.ToolReview])
async def get_reviews(
    tool_id: str,
    skip: int = 0,
    limit: int = 50,
    db: Session = Depends(get_db)
):
    """
    Get reviews for a tool
    """
    db_tool = db.query(models.Tool).filter(models.Tool.id == tool_id).first()
    if db_tool is None:
        raise HTTPException(status_code=404, detail="Tool not found")
    
    reviews = (
        db.query(models.ToolReview)
        .filter(models.ToolReview.tool_id == tool_id)
        .order_by(models.ToolReview.created_at.desc())
        .offset(skip)
        .limit(limit)
        .all()
    )
    
    return reviews

@router.post("/{tool_id}/like")
async def like_tool(
    tool_id: str,
    current_user: models.User = Depends(get_current_active_user),
    db: Session = Depends(get_db)
):
    """
    Like a tool
    """
    db_tool = db.query(models.Tool).filter(models.Tool.id == tool_id).first()
    if db_tool is None:
        raise HTTPException(status_code=404, detail="Tool not found")
    
    # Check if already liked
    existing_like = db.query(models.ToolLike).filter(
        models.ToolLike.tool_id == tool_id,
        models.ToolLike.user_id == current_user.id
    ).first()
    
    if existing_like:
        raise HTTPException(status_code=400, detail="Tool already liked")
    
    # Create like
    like = models.ToolLike(tool_id=tool_id, user_id=current_user.id)
    db.add(like)
    db.commit()
    
    return {"message": "Tool liked successfully"}

@router.delete("/{tool_id}/like")
async def unlike_tool(
    tool_id: str,
    current_user: models.User = Depends(get_current_active_user),
    db: Session = Depends(get_db)
):
    """
    Unlike a tool
    """
    db_tool = db.query(models.Tool).filter(models.Tool.id == tool_id).first()
    if db_tool is None:
        raise HTTPException(status_code=404, detail="Tool not found")
    
    # Check if already liked
    existing_like = db.query(models.ToolLike).filter(
        models.ToolLike.tool_id == tool_id,
        models.ToolLike.user_id == current_user.id
    ).first()
    
    if not existing_like:
        raise HTTPException(status_code=400, detail="Tool not liked")
    
    # Delete like
    db.delete(existing_like)
    db.commit()
    
    return {"message": "Tool unliked successfully"}

@router.post("/compare", response_model=schemas.ToolComparison)
async def compare_tools(
    comparison_data: schemas.ToolComparisonCreate,
    current_user: models.User = Depends(get_current_active_user),
    db: Session = Depends(get_db)
):
    """
    Compare up to 5 tools
    """
    # Validate number of tools
    if not comparison_data.tool_ids:
        raise HTTPException(status_code=400, detail="No tools selected for comparison")
    
    if len(comparison_data.tool_ids) > 5:
        raise HTTPException(status_code=400, detail="Maximum 5 tools can be compared")
    
    # Get tools
    tools = []
    for tool_id in comparison_data.tool_ids:
        tool = db.query(models.Tool).filter(models.Tool.id == tool_id).first()
        if not tool:
            raise HTTPException(status_code=404, detail=f"Tool with ID {tool_id} not found")
        tools.append(tool)
    
    # Save comparison for user
    # Clear existing comparison
    current_user.compared_tools = []
    for tool in tools:
        current_user.compared_tools.append(tool)
    
    db.commit()
    
    return {"tools": tools}

@router.get("/compare/current", response_model=schemas.ToolComparison)
async def get_current_comparison(
    current_user: models.User = Depends(get_current_active_user),
    db: Session = Depends(get_db)
):
    """
    Get current user's saved comparison
    """
    # Refresh user to get latest compared tools
    db.refresh(current_user)
    
    if not current_user.compared_tools:
        return {"tools": []}
    
    return {"tools": current_user.compared_tools}
