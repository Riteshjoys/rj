from fastapi import APIRouter, Depends, HTTPException, status, BackgroundTasks
from fastapi.security import OAuth2PasswordRequestForm
from sqlalchemy.orm import Session
from datetime import datetime, timedelta
import uuid

from database import get_db
import models
import schemas
from auth import (
    verify_password,
    get_password_hash,
    authenticate_user,
    create_access_token,
    get_current_active_user,
    get_user_by_email,
    generate_verification_code,
    create_verification_token,
    verify_token,
)
from email_service import email_service
from utils import is_valid_email, validate_verification_code

router = APIRouter()

@router.post("/register", response_model=schemas.Token)
async def register(
    user_data: schemas.UserCreate, 
    background_tasks: BackgroundTasks,
    db: Session = Depends(get_db)
):
    """
    Register a new user
    """
    # Check if user with this username or email already exists
    if db.query(models.User).filter(models.User.username == user_data.username).first():
        raise HTTPException(status_code=400, detail="Username already registered")
    
    if db.query(models.User).filter(models.User.email == user_data.email).first():
        raise HTTPException(status_code=400, detail="Email already registered")
    
    # Create new user
    user = models.User(
        username=user_data.username,
        email=user_data.email,
        hashed_password=get_password_hash(user_data.password),
        full_name=user_data.full_name,
        is_active=True,
        is_verified=False,  # Will be set to True after email verification
        verification_code=generate_verification_code(),
        verification_code_expiry=datetime.utcnow() + timedelta(minutes=10)
    )
    
    db.add(user)
    db.commit()
    db.refresh(user)
    
    # Create verification token for email verification
    token = create_verification_token(db, user.id, "email_verification")
    
    # Generate verification link
    verification_link = f"http://localhost:5000/verify-email?token={token.token}"
    
    # Send welcome email with verification link
    background_tasks.add_task(
        email_service.send_welcome_email,
        user.email,
        verification_link
    )
    
    # Create access token
    access_token = create_access_token(
        data={"sub": user.username}
    )
    
    return {
        "access_token": access_token,
        "token_type": "bearer",
        "user": user
    }

@router.post("/login", response_model=schemas.Token)
async def login(
    form_data: OAuth2PasswordRequestForm = Depends(),
    db: Session = Depends(get_db)
):
    """
    Login and get access token
    """
    # Authenticate user
    user = authenticate_user(db, form_data.username, form_data.password)
    if not user:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Incorrect username or password",
            headers={"WWW-Authenticate": "Bearer"},
        )
    
    # Check if user is verified
    if not user.is_verified:
        # Generate new verification code
        user.verification_code = generate_verification_code()
        user.verification_code_expiry = datetime.utcnow() + timedelta(minutes=10)
        db.commit()
        
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Email not verified. A new verification code has been sent.",
        )
    
    # Create access token
    access_token = create_access_token(
        data={"sub": user.username}
    )
    
    return {
        "access_token": access_token,
        "token_type": "bearer",
        "user": user
    }

@router.post("/two-factor-auth", response_model=schemas.Token)
async def two_factor_auth(
    auth_data: schemas.TwoFactorAuth,
    db: Session = Depends(get_db)
):
    """
    Verify two-factor authentication code
    """
    # Get user by email
    user = get_user_by_email(db, auth_data.email)
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    
    # Check if verification code is valid
    if not user.verification_code or not user.verification_code_expiry:
        raise HTTPException(status_code=400, detail="No verification code found")
    
    # Check if verification code has expired
    if user.verification_code_expiry < datetime.utcnow():
        raise HTTPException(status_code=400, detail="Verification code has expired")
    
    # Check if verification code is correct
    if not validate_verification_code(user.verification_code, auth_data.verification_code):
        raise HTTPException(status_code=400, detail="Invalid verification code")
    
    # Update user verification status
    user.is_verified = True
    user.verification_code = None
    user.verification_code_expiry = None
    db.commit()
    
    # Create access token
    access_token = create_access_token(
        data={"sub": user.username}
    )
    
    return {
        "access_token": access_token,
        "token_type": "bearer",
        "user": user
    }

@router.post("/request-verification-code")
async def request_verification_code(
    email: str,
    background_tasks: BackgroundTasks,
    db: Session = Depends(get_db)
):
    """
    Request a new verification code
    """
    # Check if email is valid
    if not is_valid_email(email):
        raise HTTPException(status_code=400, detail="Invalid email format")
    
    # Get user by email
    user = get_user_by_email(db, email)
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    
    # Generate new verification code
    verification_code = generate_verification_code()
    user.verification_code = verification_code
    user.verification_code_expiry = datetime.utcnow() + timedelta(minutes=10)
    db.commit()
    
    # Send verification email
    background_tasks.add_task(
        email_service.send_verification_email,
        user.email,
        verification_code
    )
    
    return {"message": "Verification code sent to your email"}

@router.post("/reset-password")
async def request_password_reset(
    email: str,
    background_tasks: BackgroundTasks,
    db: Session = Depends(get_db)
):
    """
    Request a password reset
    """
    # Check if email is valid
    if not is_valid_email(email):
        raise HTTPException(status_code=400, detail="Invalid email format")
    
    # Get user by email
    user = get_user_by_email(db, email)
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    
    # Create verification token for password reset
    token = create_verification_token(db, user.id, "password_reset")
    
    # Generate reset link
    reset_link = f"http://localhost:5000/reset-password?token={token.token}"
    
    # Send password reset email
    background_tasks.add_task(
        email_service.send_password_reset_email,
        user.email,
        reset_link
    )
    
    return {"message": "Password reset instructions sent to your email"}

@router.post("/reset-password/{token}")
async def reset_password(
    token: str,
    new_password: str,
    db: Session = Depends(get_db)
):
    """
    Reset password using a token
    """
    # Verify token
    db_token = verify_token(db, token, "password_reset")
    if not db_token:
        raise HTTPException(status_code=400, detail="Invalid or expired token")
    
    # Get user
    user = db.query(models.User).get(db_token.user_id)
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    
    # Update password
    user.hashed_password = get_password_hash(new_password)
    
    # Mark token as used
    db_token.is_used = True
    
    db.commit()
    
    return {"message": "Password reset successful"}

@router.get("/verify-email/{token}")
async def verify_email(
    token: str,
    db: Session = Depends(get_db)
):
    """
    Verify email using a token
    """
    # Verify token
    db_token = verify_token(db, token, "email_verification")
    if not db_token:
        raise HTTPException(status_code=400, detail="Invalid or expired token")
    
    # Get user
    user = db.query(models.User).get(db_token.user_id)
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    
    # Update verification status
    user.is_verified = True
    
    # Mark token as used
    db_token.is_used = True
    
    db.commit()
    
    return {"message": "Email verified successfully"}

@router.get("/me", response_model=schemas.User)
async def get_me(current_user: models.User = Depends(get_current_active_user)):
    """
    Get current user information
    """
    return current_user
