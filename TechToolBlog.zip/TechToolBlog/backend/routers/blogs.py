from fastapi import APIRouter, Depends, HTTPException, status, Query
from sqlalchemy.orm import Session
from typing import List, Optional
from datetime import datetime
import uuid

from database import get_db
import models
import schemas
from auth import (
    get_current_active_user,
    get_current_admin_user,
)
from utils import get_unique_slug

router = APIRouter()

@router.get("/", response_model=List[schemas.Blog])
async def get_blogs(
    skip: int = 0,
    limit: int = 20,
    category_id: Optional[str] = None,
    status: Optional[str] = None,
    sort_by: Optional[str] = "created_at",
    order: Optional[str] = "desc",
    search: Optional[str] = None,
    db: Session = Depends(get_db)
):
    """
    Get list of blogs with filtering and sorting
    """
    # Base query
    query = db.query(models.Blog)
    
    # Filter by status
    if status:
        query = query.filter(models.Blog.status == status)
    else:
        # If no status specified, only return published blogs
        query = query.filter(models.Blog.status == models.BlogStatus.PUBLISHED)
    
    # Filter by category
    if category_id:
        query = query.join(models.blog_category).join(models.Category).filter(
            models.Category.id == category_id
        )
    
    # Search
    if search:
        query = query.filter(
            (models.Blog.title.ilike(f"%{search}%")) | 
            (models.Blog.content.ilike(f"%{search}%")) |
            (models.Blog.excerpt.ilike(f"%{search}%"))
        )
    
    # Sort
    if sort_by == "created_at":
        sort_col = models.Blog.created_at
    elif sort_by == "updated_at":
        sort_col = models.Blog.updated_at
    elif sort_by == "published_at":
        sort_col = models.Blog.published_at
    elif sort_by == "title":
        sort_col = models.Blog.title
    elif sort_by == "view_count":
        sort_col = models.Blog.view_count
    elif sort_by == "like_count":
        sort_col = models.Blog.like_count
    else:
        sort_col = models.Blog.created_at
    
    # Order
    if order == "asc":
        query = query.order_by(sort_col.asc())
    else:
        query = query.order_by(sort_col.desc())
    
    # Pagination
    blogs = query.offset(skip).limit(limit).all()
    return blogs

@router.get("/my-blogs", response_model=List[schemas.Blog])
async def get_my_blogs(
    skip: int = 0,
    limit: int = 20,
    status: Optional[str] = None,
    current_user: models.User = Depends(get_current_active_user),
    db: Session = Depends(get_db)
):
    """
    Get current user's blogs
    """
    # Base query
    query = db.query(models.Blog).filter(models.Blog.author_id == current_user.id)
    
    # Filter by status
    if status:
        query = query.filter(models.Blog.status == status)
    
    # Sort by created date (newest first)
    query = query.order_by(models.Blog.created_at.desc())
    
    # Pagination
    blogs = query.offset(skip).limit(limit).all()
    return blogs

@router.get("/{blog_id}", response_model=schemas.Blog)
async def get_blog(
    blog_id: str,
    current_user: Optional[models.User] = Depends(get_current_active_user),
    db: Session = Depends(get_db)
):
    """
    Get a specific blog
    """
    blog = db.query(models.Blog).filter(models.Blog.id == blog_id).first()
    if blog is None:
        raise HTTPException(status_code=404, detail="Blog not found")
    
    # Check permissions - only author or admin can view draft blogs
    if blog.status == models.BlogStatus.DRAFT:
        if not current_user or (current_user.id != blog.author_id and current_user.role != models.UserRole.ADMIN):
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Not enough permissions to view this draft",
            )
    
    # Increment view count for published blogs
    if blog.status == models.BlogStatus.PUBLISHED:
        blog.view_count += 1
        db.commit()
    
    return blog

@router.post("/", response_model=schemas.Blog)
async def create_blog(
    blog_data: schemas.BlogCreate,
    current_user: models.User = Depends(get_current_active_user),
    db: Session = Depends(get_db)
):
    """
    Create a new blog
    """
    # Generate slug if not provided
    if not blog_data.slug:
        slug = get_unique_slug(db, models.Blog, blog_data.title)
    else:
        slug = blog_data.slug
        # Check if slug is unique
        existing_blog = db.query(models.Blog).filter(models.Blog.slug == slug).first()
        if existing_blog:
            raise HTTPException(status_code=400, detail="Slug already exists")
    
    # Set published_at date if publishing
    published_at = None
    if blog_data.status == models.BlogStatus.PUBLISHED:
        published_at = datetime.utcnow()
    
    # Create blog
    db_blog = models.Blog(
        title=blog_data.title,
        slug=slug,
        content=blog_data.content,
        content_json=blog_data.content_json,
        excerpt=blog_data.excerpt,
        author_id=current_user.id,
        status=blog_data.status,
        featured_image=blog_data.featured_image,
        published_at=published_at
    )
    
    db.add(db_blog)
    db.commit()
    db.refresh(db_blog)
    
    # Add categories
    if blog_data.category_ids:
        for category_id in blog_data.category_ids:
            category = db.query(models.Category).filter(models.Category.id == category_id).first()
            if category and category.is_for_blogs:
                db_blog.categories.append(category)
        
        db.commit()
        db.refresh(db_blog)
    
    return db_blog

@router.put("/{blog_id}", response_model=schemas.Blog)
async def update_blog(
    blog_id: str,
    blog_data: schemas.BlogUpdate,
    current_user: models.User = Depends(get_current_active_user),
    db: Session = Depends(get_db)
):
    """
    Update a blog
    """
    db_blog = db.query(models.Blog).filter(models.Blog.id == blog_id).first()
    if db_blog is None:
        raise HTTPException(status_code=404, detail="Blog not found")
    
    # Check permissions - only author or admin can update
    if current_user.id != db_blog.author_id and current_user.role != models.UserRole.ADMIN:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Not enough permissions",
        )
    
    # Update slug if title changed and slug not provided
    if blog_data.title and not blog_data.slug and blog_data.title != db_blog.title:
        blog_data.slug = get_unique_slug(db, models.Blog, blog_data.title, blog_id)
    
    # Check if slug is unique
    if blog_data.slug and blog_data.slug != db_blog.slug:
        existing_blog = db.query(models.Blog).filter(
            models.Blog.slug == blog_data.slug,
            models.Blog.id != blog_id
        ).first()
        if existing_blog:
            raise HTTPException(status_code=400, detail="Slug already exists")
    
    # Set published_at date if publishing for the first time
    if not db_blog.published_at and blog_data.status == models.BlogStatus.PUBLISHED:
        db_blog.published_at = datetime.utcnow()
    
    # Update blog data
    update_data = blog_data.dict(exclude_unset=True)
    for key, value in update_data.items():
        if key != "category_ids":  # Handle categories separately
            setattr(db_blog, key, value)
    
    # Update categories
    if blog_data.category_ids is not None:
        # Clear existing categories
        db_blog.categories = []
        
        # Add new categories
        for category_id in blog_data.category_ids:
            category = db.query(models.Category).filter(models.Category.id == category_id).first()
            if category and category.is_for_blogs:
                db_blog.categories.append(category)
    
    db.commit()
    db.refresh(db_blog)
    return db_blog

@router.delete("/{blog_id}")
async def delete_blog(
    blog_id: str,
    current_user: models.User = Depends(get_current_active_user),
    db: Session = Depends(get_db)
):
    """
    Delete a blog
    """
    db_blog = db.query(models.Blog).filter(models.Blog.id == blog_id).first()
    if db_blog is None:
        raise HTTPException(status_code=404, detail="Blog not found")
    
    # Check permissions - only author or admin can delete
    if current_user.id != db_blog.author_id and current_user.role != models.UserRole.ADMIN:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Not enough permissions",
        )
    
    db.delete(db_blog)
    db.commit()
    
    return {"message": "Blog deleted successfully"}

@router.post("/{blog_id}/like")
async def like_blog(
    blog_id: str,
    current_user: models.User = Depends(get_current_active_user),
    db: Session = Depends(get_db)
):
    """
    Like a blog
    """
    db_blog = db.query(models.Blog).filter(models.Blog.id == blog_id).first()
    if db_blog is None:
        raise HTTPException(status_code=404, detail="Blog not found")
    
    # Check if already liked
    existing_like = db.query(models.BlogLike).filter(
        models.BlogLike.blog_id == blog_id,
        models.BlogLike.user_id == current_user.id
    ).first()
    
    if existing_like:
        raise HTTPException(status_code=400, detail="Blog already liked")
    
    # Create like
    like = models.BlogLike(blog_id=blog_id, user_id=current_user.id)
    db.add(like)
    
    # Increment like count
    db_blog.like_count += 1
    
    db.commit()
    
    return {"message": "Blog liked successfully"}

@router.delete("/{blog_id}/like")
async def unlike_blog(
    blog_id: str,
    current_user: models.User = Depends(get_current_active_user),
    db: Session = Depends(get_db)
):
    """
    Unlike a blog
    """
    db_blog = db.query(models.Blog).filter(models.Blog.id == blog_id).first()
    if db_blog is None:
        raise HTTPException(status_code=404, detail="Blog not found")
    
    # Check if already liked
    existing_like = db.query(models.BlogLike).filter(
        models.BlogLike.blog_id == blog_id,
        models.BlogLike.user_id == current_user.id
    ).first()
    
    if not existing_like:
        raise HTTPException(status_code=400, detail="Blog not liked")
    
    # Delete like
    db.delete(existing_like)
    
    # Decrement like count
    if db_blog.like_count > 0:
        db_blog.like_count -= 1
    
    db.commit()
    
    return {"message": "Blog unliked successfully"}

@router.post("/{blog_id}/comment", response_model=schemas.BlogComment)
async def add_comment(
    blog_id: str,
    comment_data: schemas.BlogCommentCreate,
    current_user: models.User = Depends(get_current_active_user),
    db: Session = Depends(get_db)
):
    """
    Add a comment to a blog
    """
    db_blog = db.query(models.Blog).filter(models.Blog.id == blog_id).first()
    if db_blog is None:
        raise HTTPException(status_code=404, detail="Blog not found")
    
    # Create comment
    comment = models.BlogComment(
        blog_id=blog_id,
        user_id=current_user.id,
        content=comment_data.content
    )
    
    db.add(comment)
    db.commit()
    db.refresh(comment)
    
    return comment

@router.get("/{blog_id}/comments", response_model=List[schemas.BlogComment])
async def get_comments(
    blog_id: str,
    skip: int = 0,
    limit: int = 50,
    db: Session = Depends(get_db)
):
    """
    Get comments for a blog
    """
    db_blog = db.query(models.Blog).filter(models.Blog.id == blog_id).first()
    if db_blog is None:
        raise HTTPException(status_code=404, detail="Blog not found")
    
    comments = (
        db.query(models.BlogComment)
        .filter(models.BlogComment.blog_id == blog_id)
        .order_by(models.BlogComment.created_at.desc())
        .offset(skip)
        .limit(limit)
        .all()
    )
    
    return comments
