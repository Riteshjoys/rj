from sqlalchemy import Boolean, Column, ForeignKey, Integer, String, Text, Float, DateTime, Table, Enum, JSON
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func
import enum
from database import Base
import uuid
from sqlalchemy.dialects.postgresql import UUID

# Association table for many-to-many relationship between tools and categories
tool_category = Table(
    "tool_category",
    Base.metadata,
    Column("tool_id", UUID(as_uuid=True), ForeignKey("tools.id")),
    Column("category_id", UUID(as_uuid=True), ForeignKey("categories.id"))
)

# Association table for many-to-many relationship between blogs and categories
blog_category = Table(
    "blog_category",
    Base.metadata,
    Column("blog_id", UUID(as_uuid=True), ForeignKey("blogs.id")),
    Column("category_id", UUID(as_uuid=True), ForeignKey("categories.id"))
)

# Association table for tool comparison (user can select up to 5 tools to compare)
comparison = Table(
    "tool_comparison",
    Base.metadata,
    Column("user_id", UUID(as_uuid=True), ForeignKey("users.id")),
    Column("tool_id", UUID(as_uuid=True), ForeignKey("tools.id"))
)

# Enum for user roles
class UserRole(str, enum.Enum):
    ADMIN = "admin"
    SUPER_USER = "super_user"
    USER = "user"

# Enum for blog status
class BlogStatus(str, enum.Enum):
    DRAFT = "draft"
    PUBLISHED = "published"

# User model
class User(Base):
    __tablename__ = "users"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4, index=True)
    email = Column(String, unique=True, index=True)
    username = Column(String, unique=True, index=True)
    hashed_password = Column(String)
    full_name = Column(String)
    role = Column(Enum(UserRole), default=UserRole.USER)
    is_active = Column(Boolean, default=True)
    is_verified = Column(Boolean, default=False)
    verification_code = Column(String, nullable=True)
    verification_code_expiry = Column(DateTime, nullable=True)
    created_at = Column(DateTime, server_default=func.now())
    updated_at = Column(DateTime, server_default=func.now(), onupdate=func.now())

    # Relationships
    blogs = relationship("Blog", back_populates="author")
    tools_liked = relationship("ToolLike", back_populates="user")
    tools_reviewed = relationship("ToolReview", back_populates="user")
    compared_tools = relationship("Tool", secondary=comparison)
    
# Category model (for both blogs and tools)
class Category(Base):
    __tablename__ = "categories"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4, index=True)
    name = Column(String, unique=True, index=True)
    description = Column(Text, nullable=True)
    parent_id = Column(UUID(as_uuid=True), ForeignKey("categories.id"), nullable=True)
    is_for_tools = Column(Boolean, default=True)  # True for tools, False for blogs
    is_for_blogs = Column(Boolean, default=True)  # Can be used for both
    created_at = Column(DateTime, server_default=func.now())
    updated_at = Column(DateTime, server_default=func.now(), onupdate=func.now())

    # Self-referential relationship for subcategories
    subcategories = relationship("Category", 
                                remote_side=[id],
                                backref="parent_category")
    
    # Relationships
    tools = relationship("Tool", secondary=tool_category, back_populates="categories")
    blogs = relationship("Blog", secondary=blog_category, back_populates="categories")

# Tool model
class Tool(Base):
    __tablename__ = "tools"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4, index=True)
    name = Column(String, index=True)
    description = Column(Text)
    website_url = Column(String)
    pricing_info = Column(Text, nullable=True)
    logo_url = Column(String, nullable=True)
    features = Column(JSON, nullable=True)
    average_rating = Column(Float, default=0.0)
    created_at = Column(DateTime, server_default=func.now())
    updated_at = Column(DateTime, server_default=func.now(), onupdate=func.now())

    # Relationships
    categories = relationship("Category", secondary=tool_category, back_populates="tools")
    reviews = relationship("ToolReview", back_populates="tool", cascade="all, delete-orphan")
    likes = relationship("ToolLike", back_populates="tool", cascade="all, delete-orphan")

# Tool Review model
class ToolReview(Base):
    __tablename__ = "tool_reviews"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4, index=True)
    user_id = Column(UUID(as_uuid=True), ForeignKey("users.id"))
    tool_id = Column(UUID(as_uuid=True), ForeignKey("tools.id"))
    rating = Column(Float)
    content = Column(Text)
    created_at = Column(DateTime, server_default=func.now())
    updated_at = Column(DateTime, server_default=func.now(), onupdate=func.now())

    # Relationships
    user = relationship("User", back_populates="tools_reviewed")
    tool = relationship("Tool", back_populates="reviews")

# Tool Like model
class ToolLike(Base):
    __tablename__ = "tool_likes"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4, index=True)
    user_id = Column(UUID(as_uuid=True), ForeignKey("users.id"))
    tool_id = Column(UUID(as_uuid=True), ForeignKey("tools.id"))
    created_at = Column(DateTime, server_default=func.now())

    # Relationships
    user = relationship("User", back_populates="tools_liked")
    tool = relationship("Tool", back_populates="likes")

# Blog model
class Blog(Base):
    __tablename__ = "blogs"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4, index=True)
    title = Column(String, index=True)
    slug = Column(String, unique=True, index=True)
    content = Column(Text)
    content_json = Column(JSON, nullable=True)  # For rich text editor content
    excerpt = Column(Text, nullable=True)
    author_id = Column(UUID(as_uuid=True), ForeignKey("users.id"))
    status = Column(Enum(BlogStatus), default=BlogStatus.DRAFT)
    featured_image = Column(String, nullable=True)
    view_count = Column(Integer, default=0)
    like_count = Column(Integer, default=0)
    created_at = Column(DateTime, server_default=func.now())
    updated_at = Column(DateTime, server_default=func.now(), onupdate=func.now())
    published_at = Column(DateTime, nullable=True)

    # Relationships
    author = relationship("User", back_populates="blogs")
    categories = relationship("Category", secondary=blog_category, back_populates="blogs")
    comments = relationship("BlogComment", back_populates="blog", cascade="all, delete-orphan")
    likes = relationship("BlogLike", back_populates="blog", cascade="all, delete-orphan")

# Blog Comment model
class BlogComment(Base):
    __tablename__ = "blog_comments"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4, index=True)
    blog_id = Column(UUID(as_uuid=True), ForeignKey("blogs.id"))
    user_id = Column(UUID(as_uuid=True), ForeignKey("users.id"))
    content = Column(Text)
    created_at = Column(DateTime, server_default=func.now())
    updated_at = Column(DateTime, server_default=func.now(), onupdate=func.now())

    # Relationships
    blog = relationship("Blog", back_populates="comments")
    user = relationship("User")

# Blog Like model
class BlogLike(Base):
    __tablename__ = "blog_likes"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4, index=True)
    blog_id = Column(UUID(as_uuid=True), ForeignKey("blogs.id"))
    user_id = Column(UUID(as_uuid=True), ForeignKey("users.id"))
    created_at = Column(DateTime, server_default=func.now())

    # Relationships
    blog = relationship("Blog", back_populates="likes")
    user = relationship("User")

# Verification Token model for email verification and password reset
class VerificationToken(Base):
    __tablename__ = "verification_tokens"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4, index=True)
    user_id = Column(UUID(as_uuid=True), ForeignKey("users.id"))
    token = Column(String, unique=True, index=True)
    type = Column(String)  # "email_verification", "password_reset", etc.
    expires_at = Column(DateTime)
    created_at = Column(DateTime, server_default=func.now())
    is_used = Column(Boolean, default=False)

    # Relationship
    user = relationship("User")
