import os
import re
import csv
import io
from typing import Dict, List, Any, Tuple, Optional
from sqlalchemy.orm import Session
import pandas as pd
from slugify import slugify

# Function to create a slug from a title
def create_slug(title: str) -> str:
    """
    Create a slug from a title
    """
    return slugify(title)

# Function to check if a slug exists and generate a unique one if needed
def get_unique_slug(db: Session, model, title: str, instance_id=None) -> str:
    """
    Generate a unique slug for a model instance
    """
    slug = create_slug(title)
    original_slug = slug
    counter = 1
    
    # Check if the slug exists
    while True:
        # Query for existing slug
        query = db.query(model).filter(model.slug == slug)
        
        # If we're updating an existing instance, exclude it from the query
        if instance_id:
            query = query.filter(model.id != instance_id)
            
        # If no instance found with this slug, it's unique
        if not query.first():
            break
            
        # Otherwise, append counter to slug and increment
        slug = f"{original_slug}-{counter}"
        counter += 1
        
    return slug

# Function to process CSV file for bulk tool import
def process_csv_for_tools(file, db: Session) -> Tuple[int, List[Dict[str, Any]], str]:
    """
    Process a CSV file for bulk tool import
    
    Returns:
        int: Number of tools imported
        List[Dict]: List of failed entries
        str: Status message
    """
    try:
        # Read CSV
        df = pd.read_csv(file.file)
        
        # Validate required columns
        required_columns = ['name', 'description', 'website_url']
        for col in required_columns:
            if col not in df.columns:
                return 0, [], f"Missing required column: {col}"
        
        # Convert DataFrame to list of dictionaries
        tools_data = df.to_dict('records')
        
        # Import statistics
        imported_count = 0
        failed_entries = []
        
        # Return processed data
        return len(tools_data), failed_entries, "CSV processed successfully"
        
    except Exception as e:
        return 0, [], f"Error processing CSV: {str(e)}"

# Function to validate website URL
def is_valid_url(url: str) -> bool:
    """
    Validate if a string is a valid URL
    """
    pattern = re.compile(
        r'^(?:http|ftp)s?://'  # http:// or https://
        r'(?:(?:[A-Z0-9](?:[A-Z0-9-]{0,61}[A-Z0-9])?\.)+(?:[A-Z]{2,6}\.?|[A-Z0-9-]{2,}\.?)|'  # domain
        r'localhost|'  # localhost
        r'\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})'  # or IP
        r'(?::\d+)?'  # optional port
        r'(?:/?|[/?]\S+)$', re.IGNORECASE)
    return bool(pattern.match(url))

# Function to calculate trending score
def calculate_trending_score(views: int, likes: int, comments: int, recency_days: float) -> float:
    """
    Calculate a trending score based on views, likes, comments, and recency
    
    Higher is more trending
    """
    # Simple algorithm: (views/10 + likes*5 + comments*10) / (recency_days + 1)
    return (views/10 + likes*5 + comments*10) / (recency_days + 1)

# Function to split text for search
def prepare_text_for_search(text: str) -> str:
    """
    Prepare text for full-text search
    """
    # Remove special characters, lowercase everything
    cleaned = re.sub(r'[^\w\s]', ' ', text.lower())
    # Replace multiple spaces with single space
    cleaned = re.sub(r'\s+', ' ', cleaned)
    return cleaned.strip()

# Function to validate an email
def is_valid_email(email: str) -> bool:
    """
    Validate if a string is a valid email
    """
    pattern = re.compile(r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$')
    return bool(pattern.match(email))

# Function to securely validate a verification code
def validate_verification_code(stored_code: str, user_input: str) -> bool:
    """
    Validate a verification code with constant-time comparison to prevent timing attacks
    """
    if not stored_code or not user_input:
        return False
        
    # Ensure same length for constant time comparison
    if len(stored_code) != len(user_input):
        return False
        
    # Use constant time comparison to prevent timing attacks
    result = 0
    for x, y in zip(stored_code, user_input):
        result |= ord(x) ^ ord(y)
    return result == 0
